# Clipazos para Android

App 100 % Android (no necesita PC ni Windows). El video se procesa en el teléfono; solo la transcripción y la
elección inteligente de clips usan servicios de IA con tus propias claves.

## Cómo compilarla con GitHub (sin PC)
1. En tu repositorio, subí `clipazos-android.zip` **sin descomprimir**, a la raíz.
2. Creá el archivo `.github/workflows/build-apk.yml` y pegá el código del workflow.
3. Pestaña **Actions** → "Compilar Clipazos (Android)" → **Run workflow** (también corre solo al subir el zip).
4. Al terminar (unos 5 min), abrí la ejecución y bajá **Clipazos-Android** (Artifacts): adentro está `app-debug.apk`.
5. Instalalo en el teléfono (permití "instalar apps desconocidas").

## Primer uso
- Configuración → cargá la clave de transcripción (OpenAI, o Groq que tiene plan gratuito) y la de Anthropic (Claude).
- Sin claves la app funciona igual: elige clips por energía de audio y no genera subtítulos.

## Límites actuales
- Exporta en tiempo real (un clip de 45 s tarda ~45 s): dejá la app abierta y la pantalla encendida.
- Hasta 1080p. Sin 4K, sin importar desde YouTube, sin seguimiento del hablante ni reencuadre automático.
- La puntuación de potencial viral es solo una estimación.
- Música: la subís vos desde el teléfono; los efectos de sonido se generan en la app.
