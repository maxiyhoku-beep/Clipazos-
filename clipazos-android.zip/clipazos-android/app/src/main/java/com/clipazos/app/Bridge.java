package com.clipazos.app;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.StatFs;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Funciones nativas que la interfaz (JavaScript) llama como window.Android.* */
public class Bridge {
    private final MainActivity act;
    private final WebView web;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final File projects;

    private String pickReq;
    private final AtomicBoolean pickCancel = new AtomicBoolean(false);
    private final Map<String, AtomicBoolean> analysisCancel = new HashMap<>();

    private static class Save { Uri uri; OutputStream os; String name; long size; }
    private final Map<String, Save> saves = new HashMap<>();

    Bridge(MainActivity act, WebView web) {
        this.act = act;
        this.web = web;
        this.projects = new File(act.getFilesDir(), "projects");
        projects.mkdirs();
    }

    void shutdown() { pool.shutdownNow(); }

    /* ---------- utilidades ---------- */
    private void js(final String code) { act.runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(code, null); } }); }
    private static String q(String s) { return JSONObject.quote(s); }
    private void resolve(String id, JSONObject o) { js("window.__native.resolve(" + q(id) + "," + o.toString() + ")"); }
    private void progress(String id, long a, long b) { js("window.__native.progress(" + q(id) + "," + a + "," + b + ")"); }
    private JSONObject err(String m) { try { return new JSONObject().put("error", m); } catch (Exception e) { return new JSONObject(); } }
    private static boolean okId(String s) { return s != null && s.matches("[A-Za-z0-9_-]{1,64}"); }

    private static void rmrf(File f) {
        File[] k = f.listFiles();
        if (k != null) for (File c : k) rmrf(c);
        f.delete();
    }

    /* ---------- elegir y copiar el video ---------- */
    @JavascriptInterface
    public void pickVideo(final String reqId) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                pickReq = reqId;
                pickCancel.set(false);
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("video/*");
                try { act.startActivityForResult(i, MainActivity.REQ_PICK); }
                catch (Exception e) { resolve(reqId, err("No se pudo abrir el selector de videos.")); pickReq = null; }
            }
        });
    }

    @JavascriptInterface
    public void cancelPick() { pickCancel.set(true); }

    void onPickResult(int res, Intent data) {
        final String reqId = pickReq;
        pickReq = null;
        if (reqId == null) return;
        if (res != android.app.Activity.RESULT_OK || data == null || data.getData() == null) {
            try { resolve(reqId, new JSONObject().put("canceled", true)); } catch (Exception ignored) { }
            return;
        }
        final Uri uri = data.getData();
        pool.execute(new Runnable() {
            public void run() { copyVideo(reqId, uri); }
        });
    }

    private void copyVideo(String reqId, Uri uri) {
        File dir = null;
        try {
            String name = "video.mp4";
            long size = -1;
            Cursor c = act.getContentResolver().query(uri, null, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) {
                        int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME), si = c.getColumnIndex(OpenableColumns.SIZE);
                        if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                        if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
                    }
                } finally { c.close(); }
            }
            String ext = "mp4";
            int dot = name.lastIndexOf('.');
            if (dot >= 0 && dot < name.length() - 1) {
                String e = name.substring(dot + 1).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                if (e.length() > 0 && e.length() <= 5) ext = e;
            }
            if (size > 0) {
                StatFs st = new StatFs(act.getFilesDir().getAbsolutePath());
                if (st.getAvailableBytes() < size + 100L * 1024 * 1024) {
                    resolve(reqId, err("No hay espacio libre suficiente en el teléfono para copiar este video (" + (size / 1048576) + " MB)."));
                    return;
                }
            }
            String id = UUID.randomUUID().toString().replace("-", "").substring(0, 10);
            dir = new File(projects, id);
            dir.mkdirs();
            File dst = new File(dir, "source." + ext);
            long done = 0, last = 0;
            try (InputStream in = act.getContentResolver().openInputStream(uri); java.io.FileOutputStream out = new java.io.FileOutputStream(dst)) {
                if (in == null) throw new Exception("No se pudo leer el video.");
                byte[] buf = new byte[1 << 20];
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (pickCancel.get()) { out.close(); rmrf(dir); resolve(reqId, new JSONObject().put("canceled", true)); return; }
                    out.write(buf, 0, n);
                    done += n;
                    long now = System.currentTimeMillis();
                    if (now - last > 250) { last = now; progress(reqId, done, size > 0 ? size : done); }
                }
            }
            progress(reqId, done, done);
            JSONObject o = new JSONObject();
            o.put("id", id).put("name", name).put("ext", ext).put("size", done);
            resolve(reqId, o);
        } catch (Exception e) {
            if (dir != null) rmrf(dir);
            resolve(reqId, err("No se pudo copiar el video: " + e.getMessage()));
        }
    }

    /* ---------- análisis de audio ---------- */
    @JavascriptInterface
    public void analyzeAudio(final String reqId, final String pid) {
        if (!okId(pid)) { resolve(reqId, err("Proyecto inválido")); return; }
        final AtomicBoolean flag = new AtomicBoolean(false);
        synchronized (analysisCancel) { analysisCancel.put(pid, flag); }
        pool.execute(new Runnable() {
            public void run() {
                try {
                    File dir = new File(projects, pid);
                    File src = null;
                    File[] fs = dir.listFiles();
                    if (fs != null) for (File f : fs) if (f.getName().startsWith("source.")) src = f;
                    if (src == null) { resolve(reqId, err("No se encontró el video del proyecto.")); return; }
                    File out = new File(dir, "audio");
                    rmrf(out);
                    AudioExtractor ax = new AudioExtractor(src, out, pid + "/audio/", flag, new AudioExtractor.Progress() {
                        public void on(long d, long t) { progress(reqId, d, t); }
                    });
                    resolve(reqId, ax.run());
                } catch (InterruptedException e) {
                    resolve(reqId, err("Cancelado"));
                } catch (Throwable e) {
                    resolve(reqId, err("No se pudo leer el audio del video: " + e.getMessage()));
                } finally {
                    synchronized (analysisCancel) { analysisCancel.remove(pid); }
                }
            }
        });
    }

    @JavascriptInterface
    public void cancelAnalysis(String pid) {
        synchronized (analysisCancel) { AtomicBoolean f = analysisCancel.get(pid); if (f != null) f.set(true); }
    }

    /* ---------- internet ---------- */
    @JavascriptInterface
    public void http(final String reqId, final String spec) {
        pool.execute(new Runnable() { public void run() { resolve(reqId, Http.run(projects, spec)); } });
    }

    /* ---------- guardar el video exportado en la galería ---------- */
    @JavascriptInterface
    public String saveBegin(String name, String mime) {
        try {
            String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (mime == null || !mime.startsWith("video/")) mime = "video/mp4";
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, safe);
            v.put(MediaStore.Video.Media.MIME_TYPE, mime.split(";")[0]);
            v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Clipazos");
            v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri uri = act.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return "ERR:No se pudo crear el archivo en la galería";
            Save s = new Save();
            s.uri = uri; s.name = safe; s.os = act.getContentResolver().openOutputStream(uri);
            String h = UUID.randomUUID().toString();
            synchronized (saves) { saves.put(h, s); }
            return h;
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }

    @JavascriptInterface
    public String saveChunk(String h, String b64) {
        Save s;
        synchronized (saves) { s = saves.get(h); }
        if (s == null) return "ERR:Guardado inválido";
        try {
            byte[] b = Base64.decode(b64, Base64.DEFAULT);
            s.os.write(b);
            s.size += b.length;
            return "OK";
        } catch (Exception e) {
            return "ERR:" + e.getMessage();
        }
    }

    @JavascriptInterface
    public String saveEnd(String h) {
        Save s;
        synchronized (saves) { s = saves.remove(h); }
        try {
            if (s == null) throw new Exception("Guardado inválido");
            s.os.close();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.IS_PENDING, 0);
            act.getContentResolver().update(s.uri, v, null, null);
            return new JSONObject().put("uri", s.uri.toString()).put("name", s.name).put("size", s.size).toString();
        } catch (Exception e) {
            return err(e.getMessage()).toString();
        }
    }

    @JavascriptInterface
    public void saveAbort(String h) {
        Save s;
        synchronized (saves) { s = saves.remove(h); }
        if (s == null) return;
        try { s.os.close(); } catch (Exception ignored) { }
        try { act.getContentResolver().delete(s.uri, null, null); } catch (Exception ignored) { }
    }

    /* ---------- abrir / compartir / borrar ---------- */
    @JavascriptInterface
    public void openUri(final String uri, final String mime) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setDataAndType(Uri.parse(uri), mime == null || mime.isEmpty() ? "video/mp4" : mime.split(";")[0]);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(i);
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void share(final String uri, final String mime) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(mime == null || mime.isEmpty() ? "video/mp4" : mime.split(";")[0]);
                    i.putExtra(Intent.EXTRA_STREAM, Uri.parse(uri));
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(i, "Compartir clip"));
                } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public boolean deleteUri(String uri) {
        try { return act.getContentResolver().delete(Uri.parse(uri), null, null) > 0; }
        catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void deleteProject(String pid) {
        if (okId(pid)) rmrf(new File(projects, pid));
    }

    @JavascriptInterface
    public void keepAwake(final boolean on) {
        act.runOnUiThread(new Runnable() {
            public void run() {
                if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }
}
