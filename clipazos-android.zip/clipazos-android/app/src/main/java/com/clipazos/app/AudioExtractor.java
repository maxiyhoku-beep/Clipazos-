package com.clipazos.app;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Decodifica el audio del video, lo baja a mono 16 kHz, lo parte en trozos WAV de 10 minutos
 * (para el límite de 25 MB de los servicios de transcripción) y calcula la energía (dB) de cada segundo.
 */
final class AudioExtractor {
    interface Progress { void on(long done, long total); }

    static final int RATE = 16000;
    static final int CHUNK_SECONDS = 600;

    private final File video, outDir;
    private final String relPrefix;
    private final AtomicBoolean cancel;
    private final Progress progress;

    private RandomAccessFile wav;
    private long wavSamples;
    private int chunkIndex;
    private final JSONArray chunks = new JSONArray();
    private final StringBuilder energy = new StringBuilder("[");
    private int energyCount;
    private double sumSq;
    private int secCount;
    private long outTotal;

    AudioExtractor(File video, File outDir, String relPrefix, AtomicBoolean cancel, Progress progress) {
        this.video = video; this.outDir = outDir; this.relPrefix = relPrefix; this.cancel = cancel; this.progress = progress;
    }

    JSONObject run() throws Exception {
        JSONObject res = new JSONObject();
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(video.getAbsolutePath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) { res.put("hasAudio", false); return res; }
            ex.selectTrack(track);
            long durUs = fmt.containsKey(MediaFormat.KEY_DURATION) ? fmt.getLong(MediaFormat.KEY_DURATION) : 0;

            outDir.mkdirs();
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();

            int inRate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            int channels = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            boolean floatPcm = false;

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false, outDone = false;
            long phase = 0;
            double acc = 0;
            int accN = 0;
            long lastReport = 0;

            while (!outDone) {
                if (cancel.get()) throw new InterruptedException("cancelado");
                if (!inDone) {
                    int ib = codec.dequeueInputBuffer(10000);
                    if (ib >= 0) {
                        ByteBuffer buf = codec.getInputBuffer(ib);
                        int n = ex.readSampleData(buf, 0);
                        if (n < 0) { codec.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true; }
                        else { codec.queueInputBuffer(ib, 0, n, ex.getSampleTime(), 0); ex.advance(); }
                    }
                }
                int ob = codec.dequeueOutputBuffer(info, 10000);
                if (ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    floatPcm = of.containsKey(MediaFormat.KEY_PCM_ENCODING) && of.getInteger(MediaFormat.KEY_PCM_ENCODING) == 4; // ENCODING_PCM_FLOAT
                } else if (ob >= 0) {
                    ByteBuffer out = codec.getOutputBuffer(ob);
                    if (out != null && info.size > 0) {
                        out.position(info.offset);
                        out.limit(info.offset + info.size);
                        out.order(ByteOrder.LITTLE_ENDIAN);
                        int frames = info.size / ((floatPcm ? 4 : 2) * Math.max(1, channels));
                        for (int f = 0; f < frames; f++) {
                            double s = 0;
                            for (int c = 0; c < channels; c++) s += floatPcm ? out.getFloat() * 32767.0 : out.getShort();
                            acc += s / channels;
                            accN++;
                            phase += RATE;
                            if (phase >= inRate) {
                                phase -= inRate;
                                emit((short) Math.max(-32768, Math.min(32767, Math.round(acc / accN))));
                                acc = 0; accN = 0;
                            }
                        }
                    }
                    codec.releaseOutputBuffer(ob, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    if (progress != null && info.presentationTimeUs - lastReport > 2_000_000) {
                        lastReport = info.presentationTimeUs;
                        progress.on(info.presentationTimeUs / 1000, Math.max(1, durUs / 1000));
                    }
                }
            }
            closeWav();
            if (secCount > RATE / 2) pushEnergy();
            energy.append("]");
            res.put("hasAudio", true);
            res.put("duration", outTotal / (double) RATE);
            res.put("chunks", chunks);
            res.put("energy", new JSONArray(energy.toString()));
            return res;
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception ignored) { }
            ex.release();
            try { if (wav != null) wav.close(); } catch (Exception ignored) { }
        }
    }

    private void emit(short s) throws Exception {
        if (wav == null) openWav();
        byte[] b = new byte[]{(byte) (s & 0xff), (byte) ((s >> 8) & 0xff)};
        buffer(b);
        wavSamples++;
        outTotal++;
        sumSq += (double) s * s;
        if (++secCount >= RATE) pushEnergy();
        if (wavSamples >= (long) CHUNK_SECONDS * RATE) closeWav();
    }

    private void pushEnergy() {
        double rms = Math.sqrt(sumSq / Math.max(1, secCount)) / 32768.0;
        double db = Math.max(-100, 20 * Math.log10(rms + 1e-9));
        if (energyCount++ > 0) energy.append(',');
        energy.append(String.format(java.util.Locale.US, "%.1f", db));
        sumSq = 0; secCount = 0;
    }

    private final byte[] wbuf = new byte[64 * 1024];
    private int wlen;

    private void buffer(byte[] b) throws IOException {
        wbuf[wlen++] = b[0];
        wbuf[wlen++] = b[1];
        if (wlen >= wbuf.length) flush();
    }

    private void flush() throws IOException {
        if (wav != null && wlen > 0) wav.write(wbuf, 0, wlen);
        wlen = 0;
    }

    private void openWav() throws IOException {
        File f = new File(outDir, "chunk_" + chunkIndex + ".wav");
        wav = new RandomAccessFile(f, "rw");
        wav.setLength(0);
        wav.write(new byte[44]);
        wavSamples = 0;
    }

    private void closeWav() throws Exception {
        if (wav == null) return;
        flush();
        long data = wavSamples * 2;
        ByteBuffer h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        h.put("RIFF".getBytes()).putInt((int) (36 + data)).put("WAVE".getBytes()).put("fmt ".getBytes())
                .putInt(16).putShort((short) 1).putShort((short) 1).putInt(RATE).putInt(RATE * 2).putShort((short) 2).putShort((short) 16)
                .put("data".getBytes()).putInt((int) data);
        wav.seek(0);
        wav.write(h.array());
        wav.close();
        wav = null;
        JSONObject c = new JSONObject();
        c.put("rel", relPrefix + "chunk_" + chunkIndex + ".wav");
        c.put("offset", (double) chunkIndex * CHUNK_SECONDS);
        c.put("duration", wavSamples / (double) RATE);
        chunks.put(c);
        chunkIndex++;
        wavSamples = 0;
    }
}
