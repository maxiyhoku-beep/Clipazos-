package com.clipazos.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

/** Pedidos HTTPS hechos desde Android (así no hay problemas de CORS). */
final class Http {
    private Http() { }

    static JSONObject run(File projectsDir, String specJson) {
        JSONObject out = new JSONObject();
        HttpURLConnection c = null;
        try {
            JSONObject spec = new JSONObject(specJson);
            URL url = new URL(spec.getString("url"));
            if (!"https".equalsIgnoreCase(url.getProtocol())) throw new Exception("Solo se permiten direcciones https.");
            c = (HttpURLConnection) url.openConnection();
            c.setConnectTimeout(30000);
            c.setReadTimeout(300000);
            c.setRequestMethod(spec.optString("method", "GET"));
            JSONObject h = spec.optJSONObject("headers");
            if (h != null) for (Iterator<String> it = h.keys(); it.hasNext(); ) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }

            JSONObject mp = spec.optJSONObject("multipart");
            if (mp != null) {
                String boundary = "----clipazos" + Long.toHexString(System.nanoTime());
                c.setDoOutput(true);
                c.setChunkedStreamingMode(64 * 1024);
                c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                OutputStream os = c.getOutputStream();
                JSONObject f = mp.optJSONObject("fields");
                if (f != null) for (Iterator<String> it = f.keys(); it.hasNext(); ) {
                    String k = it.next();
                    Object v = f.get(k);
                    if (v instanceof JSONArray) { JSONArray a = (JSONArray) v; for (int i = 0; i < a.length(); i++) field(os, boundary, k, String.valueOf(a.get(i))); }
                    else field(os, boundary, k, String.valueOf(v));
                }
                JSONObject file = mp.optJSONObject("file");
                if (file != null) {
                    File base = projectsDir.getCanonicalFile();
                    File src = new File(base, file.getString("rel")).getCanonicalFile();
                    if (!src.getPath().startsWith(base.getPath() + File.separator) || !src.isFile()) throw new Exception("Archivo de audio no encontrado.");
                    String head = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + file.getString("field") + "\"; filename=\"" + file.optString("name", "file") + "\"\r\nContent-Type: " + file.optString("type", "application/octet-stream") + "\r\n\r\n";
                    os.write(head.getBytes(StandardCharsets.UTF_8));
                    try (InputStream in = new FileInputStream(src)) {
                        byte[] buf = new byte[64 * 1024];
                        int n;
                        while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
                    }
                    os.write("\r\n".getBytes(StandardCharsets.UTF_8));
                }
                os.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                os.flush();
                os.close();
            } else if (spec.has("body")) {
                byte[] body = spec.getString("body").getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(body.length);
                OutputStream os = c.getOutputStream();
                os.write(body);
                os.close();
            }

            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            if (is != null) {
                byte[] buf = new byte[16 * 1024];
                int n;
                while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
                is.close();
            }
            out.put("status", code);
            out.put("text", new String(bo.toByteArray(), StandardCharsets.UTF_8));
        } catch (Exception e) {
            try { out = new JSONObject(); out.put("error", "No se pudo conectar: " + e.getMessage()); } catch (Exception ignored) { }
        } finally {
            if (c != null) c.disconnect();
        }
        return out;
    }

    private static void field(OutputStream os, String boundary, String name, String value) throws Exception {
        String s = "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n";
        os.write(s.getBytes(StandardCharsets.UTF_8));
    }
}
