package com.clipazos.app;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Pantalla única: un WebView que muestra la interfaz de Clipazos (carpeta assets/www). */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final int REQ_PICK = 4101, REQ_FILE = 4102;

    WebView web;
    Bridge bridge;
    ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#070a14"));
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#070a14"));
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        bridge = new Bridge(this, web);
        web.addJavascriptInterface(bridge, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u != null && HOST.equals(u.getHost())) return serve(u, r.getRequestHeaders());
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (u != null && HOST.equals(u.getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        if (b == null) web.loadUrl("https://" + HOST + "/index.html");
        else web.restoreState(b);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_PICK) { bridge.onPickResult(res, data); return; }
        if (req == REQ_FILE && fileCb != null) {
            Uri[] r = WebChromeClient.FileChooserParams.parseResult(res, data);
            fileCb.onReceiveValue(r);
            fileCb = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (isFinishing()) { bridge.shutdown(); web.destroy(); }
        super.onDestroy();
    }

    /* ---------------- servidor interno de archivos ---------------- */

    private static String mime(String p) {
        p = p.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".otf")) return "font/otf";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".mp4") || p.endsWith(".m4v")) return "video/mp4";
        if (p.endsWith(".mov")) return "video/quicktime";
        if (p.endsWith(".webm")) return "video/webm";
        if (p.endsWith(".mkv")) return "video/x-matroska";
        if (p.endsWith(".3gp")) return "video/3gpp";
        return "application/octet-stream";
    }

    private static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private WebResourceResponse serve(Uri u, Map<String, String> hdr) {
        String path = u.getPath() == null ? "/" : u.getPath();
        if (path.equals("/")) path = "/index.html";
        try {
            if (path.startsWith("/media/")) {
                String[] parts = path.split("/"); // "", media, id, source
                if (parts.length == 4 && parts[3].equals("source") && parts[2].matches("[A-Za-z0-9_-]+")) {
                    File dir = new File(new File(getFilesDir(), "projects"), parts[2]);
                    File[] fs = dir.listFiles();
                    File src = null;
                    if (fs != null) for (File f : fs) if (f.getName().startsWith("source.")) src = f;
                    if (src == null) return notFound();
                    return range(src, hdr);
                }
                return notFound();
            }
            if (path.contains("..")) return notFound();
            InputStream in = getAssets().open("www" + path);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            return new WebResourceResponse(mime(path), "utf-8", 200, "OK", h, in);
        } catch (IOException e) {
            return notFound();
        }
    }

    private WebResourceResponse range(File f, Map<String, String> hdr) throws IOException {
        long len = f.length();
        String rg = null;
        if (hdr != null) for (Map.Entry<String, String> e : hdr.entrySet()) if (e.getKey().equalsIgnoreCase("range")) rg = e.getValue();
        long a = 0, z = len - 1;
        boolean partial = false;
        if (rg != null && rg.startsWith("bytes=")) {
            try {
                String[] p = rg.substring(6).split(",")[0].trim().split("-", -1);
                if (p[0].isEmpty()) { long n = Long.parseLong(p[1]); a = Math.max(0, len - n); }
                else { a = Long.parseLong(p[0]); if (p.length > 1 && !p[1].isEmpty()) z = Math.min(len - 1, Long.parseLong(p[1])); }
                partial = true;
            } catch (Exception ignored) { a = 0; z = len - 1; partial = false; }
        }
        Map<String, String> h = new HashMap<>();
        h.put("Accept-Ranges", "bytes");
        h.put("Cache-Control", "no-store");
        if (len == 0 || a > z || a >= len) {
            h.put("Content-Range", "bytes */" + len);
            return new WebResourceResponse(mime(f.getName()), null, 416, "Range Not Satisfiable", h, new ByteArrayInputStream(new byte[0]));
        }
        FileInputStream fin = new FileInputStream(f);
        fin.getChannel().position(a);
        final long count = z - a + 1;
        InputStream in = new LimitedStream(fin, count);
        h.put("Content-Length", String.valueOf(count));
        if (partial) {
            h.put("Content-Range", "bytes " + a + "-" + z + "/" + len);
            return new WebResourceResponse(mime(f.getName()), null, 206, "Partial Content", h, in);
        }
        return new WebResourceResponse(mime(f.getName()), null, 200, "OK", h, in);
    }

    /** Lee como máximo N bytes de un stream. */
    static class LimitedStream extends InputStream {
        private final InputStream in;
        private long left;
        LimitedStream(InputStream in, long n) { this.in = in; this.left = n; }
        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int r = in.read();
            if (r >= 0) left--;
            return r;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int r = in.read(b, off, (int) Math.min(len, left));
            if (r > 0) left -= r;
            return r;
        }
        @Override public int available() throws IOException { return (int) Math.min(left, in.available()); }
        @Override public void close() throws IOException { in.close(); }
    }
}
