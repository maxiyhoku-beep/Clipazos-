'use strict';
/* Clipazos – editor de clips. La vista en vivo y la exportación usan el mismo motor de dibujo (CZ.render.drawFrame). */
(() => {
const { $, $$, esc, clamp, fmt, fmtMs, parseT, bytes, ic, api, toast, fail, modal, confirmBox, header, G } = window.__clipazos;

const R = window.CZ.render;
const SUB_PRESETS = {
  viral: { name: 'Viral amarillo', css: 'background:#111;color:#fff', sample: '<span style="color:#facc15">WOW</span> MIRÁ', v: { font: 'Poppins', size: 5.2, color: '#ffffff', highlight: '#facc15', outline: '#000000', outlineW: 12, shadow: 3, bold: true, uppercase: true, wordsPerLine: 3, anim: 'pop', highlightWords: true, box: false, italic: false } },
  clasico: { name: 'Clásico blanco', css: 'background:#222;color:#fff', sample: 'Clásico', v: { font: 'Inter', size: 4.4, color: '#ffffff', highlight: '#7dd3fc', outline: '#000000', outlineW: 10, shadow: 2, bold: true, uppercase: false, wordsPerLine: 4, anim: 'none', highlightWords: false, box: false, italic: false } },
  caja: { name: 'Caja oscura', css: 'background:#333;color:#fff', sample: '<span style="background:#000a;padding:2px 8px;border-radius:4px">Caja</span>', v: { font: 'Inter', size: 4.2, color: '#ffffff', highlight: '#22d3ee', outline: '#000000', outlineW: 0, shadow: 0, bold: true, uppercase: false, wordsPerLine: 4, anim: 'fade', highlightWords: true, box: true, boxColor: '#000000', italic: false } },
  neon: { name: 'Neón turquesa', css: 'background:#071a2a;color:#22d3ee', sample: 'NEÓN', v: { font: 'Inter Black', size: 5.2, color: '#ffffff', highlight: '#22d3ee', outline: '#0a3a5a', outlineW: 14, shadow: 4, bold: true, uppercase: true, wordsPerLine: 3, anim: 'wordpop', highlightWords: true, box: false, italic: false } },
  gaming: { name: 'Gaming violeta', css: 'background:#1a0d33;color:#c4b5fd', sample: 'GG', v: { font: 'Poppins', size: 5.2, color: '#ffffff', highlight: '#a78bfa', outline: '#2e1065', outlineW: 16, shadow: 4, bold: true, uppercase: true, wordsPerLine: 2, anim: 'wordpop', highlightWords: true, box: false, italic: true } },
  podcast: { name: 'Podcast limpio', css: 'background:#0d1b33;color:#e0f2fe', sample: 'Podcast', v: { font: 'Poppins', size: 4.0, color: '#ffffff', highlight: '#38bdf8', outline: '#0b1730', outlineW: 8, shadow: 1, bold: true, uppercase: false, wordsPerLine: 5, anim: 'fade', highlightWords: true, box: false, italic: false } },
  cine: { name: 'Cinematográfico', css: 'background:#1b1b1b;color:#f5f5f4;font-family:serif', sample: 'Cine', v: { font: 'DejaVu Serif', size: 3.8, color: '#f5f5f4', highlight: '#fcd34d', outline: '#000000', outlineW: 6, shadow: 2, bold: true, uppercase: false, wordsPerLine: 5, anim: 'fade', highlightWords: false, box: false, italic: false } },
  minimal: { name: 'Minimalista', css: 'background:#f1f5f9;color:#0f172a', sample: 'Minimal', v: { font: 'Inter', size: 3.6, color: '#ffffff', highlight: '#ffffff', outline: '#000000', outlineW: 7, shadow: 0, bold: false, uppercase: false, wordsPerLine: 6, anim: 'none', highlightWords: false, box: false, italic: false } },
};

const EDIT_STYLES = {
  streamer: { name: 'Streamer', desc: 'Zoom dinámico y colores vivos', grad: 'linear-gradient(135deg,#8b5cf6,#2f6bff)', e: { sub: 'viral', zoomMode: 'dynamic', zoom: 1.05, zoomEnd: 1.25, filter: 'vivid', transIn: 'none', transOut: 'none', border: { on: false }, framing: 'fill' } },
  podcast: { name: 'Podcast', desc: 'Sobrio, con fundidos suaves', grad: 'linear-gradient(135deg,#0ea5e9,#1e3a8a)', e: { sub: 'podcast', zoomMode: 'static', zoom: 1.1, filter: 'none', transIn: 'fade', transOut: 'fade', border: { on: false }, framing: 'fill' } },
  gaming: { name: 'Gaming', desc: 'Neón, marco y entrada con destello', grad: 'linear-gradient(135deg,#22d3ee,#8b5cf6)', e: { sub: 'gaming', zoomMode: 'dynamic', zoom: 1, zoomEnd: 1.3, filter: 'gaming', transIn: 'flash', transOut: 'none', border: { on: true, color: '#22d3ee', width: 10 }, framing: 'fill' } },
  info: { name: 'Informativo', desc: 'Subtítulos en caja, imagen nítida', grad: 'linear-gradient(135deg,#2f6bff,#14b8a6)', e: { sub: 'caja', zoomMode: 'static', zoom: 1, filter: 'sharp', transIn: 'fade', transOut: 'fade', border: { on: false }, framing: 'fill' } },
  viral: { name: 'Dinámico viral', desc: 'Máximo ritmo: zoom fuerte y palabras que saltan', grad: 'linear-gradient(135deg,#f43f5e,#f59e0b)', e: { sub: 'viral', zoomMode: 'dynamic', zoom: 1.1, zoomEnd: 1.4, filter: 'vivid', transIn: 'flash', transOut: 'none', border: { on: false }, framing: 'fill', subOver: { anim: 'wordpop', size: 5.6 } } },
  cine: { name: 'Cinematográfico', desc: 'Tono de cine, zoom lento', grad: 'linear-gradient(135deg,#334155,#78350f)', e: { sub: 'cine', zoomMode: 'dynamic', zoom: 1, zoomEnd: 1.15, filter: 'cine', transIn: 'fade', transOut: 'fade', border: { on: false }, framing: 'fill' } },
  minimal: { name: 'Minimalista', desc: 'Sin adornos', grad: 'linear-gradient(135deg,#475569,#94a3b8)', e: { sub: 'minimal', zoomMode: 'static', zoom: 1, filter: 'none', transIn: 'none', transOut: 'none', border: { on: false }, framing: 'fill' } },
};

const CSS_FILTER = { none: 'none', vivid: 'saturate(1.3) contrast(1.08)', cine: 'contrast(1.12) saturate(.9) sepia(.12) brightness(.95)', gaming: 'saturate(1.45) contrast(1.12)', bw: 'grayscale(1) contrast(1.1)', warm: 'sepia(.25) saturate(1.1)', cold: 'hue-rotate(12deg) saturate(1.05)', sharp: 'contrast(1.06)' };
const FILTER_NAMES = { none: 'Ninguno', vivid: 'Vívido', cine: 'Cine', gaming: 'Gaming', bw: 'Blanco y negro', warm: 'Cálido', cold: 'Frío', sharp: 'Nítido' };
const TRANS = { none: 'Ninguna', fade: 'Fundido', flash: 'Destello blanco' };
const FONTS = ['Poppins', 'Inter', 'Inter Black', 'DejaVu Sans', 'DejaVu Serif'];
const ANIMS = { none: 'Sin animación', pop: 'Aparece con rebote', fade: 'Fundido', wordpop: 'Palabra que crece' };
const EMOJIS = '😂 🤣 😍 😮 😱 🤯 😎 🥳 😭 😡 🤔 🙌 👏 👍 👎 🔥 💥 ⚡ ⭐ 💯 ❤️ 💔 🎉 🏆 ⚽ 🎮 💰 🚀 👀 👑 💀 🙏 ✅ ❌ ❗ ❓ ⚠️ 🎯 📌 ➡️'.split(' ');
const STICKERS = [
  { n: 'wow', t: '¡WOW!', a: '#f43f5e', b: '#f59e0b' }, { n: 'lol', t: 'JAJAJA', a: '#22d3ee', b: '#2f6bff' }, { n: 'omg', t: 'OMG', a: '#8b5cf6', b: '#ec4899' },
  { n: 'top', t: '🔥 TOP', a: '#f97316', b: '#ef4444' }, { n: 'nuevo', t: 'NUEVO', a: '#10b981', b: '#14b8a6' }, { n: 'cuidado', t: '¡CUIDADO!', a: '#facc15', b: '#f97316', dark: true },
  { n: 'cien', t: '100%', a: '#2f6bff', b: '#8b5cf6' }, { n: 'clave', t: 'CLAVE', a: '#0ea5e9', b: '#6366f1' },
  { n: 'flecha-abajo', arrow: 'down', a: '#facc15', b: '#f59e0b' }, { n: 'flecha-der', arrow: 'right', a: '#22d3ee', b: '#2f6bff' }, { n: 'flecha-izq', arrow: 'left', a: '#f43f5e', b: '#f97316' },
];

/* ---------- Generadores de medios (en el navegador) ---------- */
function canvasPng(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  return new Promise((res) => c.toBlob(res, 'image/png'));
}
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); };
function stickerBlob(s) {
  if (s.arrow) return canvasPng(400, 400, (g) => {
    const gr = g.createLinearGradient(0, 0, 400, 400); gr.addColorStop(0, s.a); gr.addColorStop(1, s.b);
    g.translate(200, 200); g.rotate(s.arrow === 'down' ? Math.PI / 2 : s.arrow === 'left' ? Math.PI : 0);
    g.beginPath(); g.moveTo(-150, -50); g.lineTo(20, -50); g.lineTo(20, -120); g.lineTo(160, 0); g.lineTo(20, 120); g.lineTo(20, 50); g.lineTo(-150, 50); g.closePath();
    g.fillStyle = gr; g.fill(); g.lineWidth = 14; g.strokeStyle = '#fff'; g.lineJoin = 'round'; g.stroke();
  });
  return canvasPng(640, 260, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, h); gr.addColorStop(0, s.a); gr.addColorStop(1, s.b);
    g.translate(w / 2, h / 2); g.rotate(-0.06); g.translate(-w / 2, -h / 2);
    rr(g, 30, 40, w - 60, h - 80, 44); g.fillStyle = gr; g.fill(); g.lineWidth = 12; g.strokeStyle = '#fff'; g.stroke();
    g.font = '800 104px Poppins, Inter, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.lineWidth = 10; g.strokeStyle = s.dark ? 'rgba(255,255,255,.0)' : 'rgba(0,0,0,.45)'; g.lineJoin = 'round';
    g.strokeText(s.t, w / 2, h / 2 + 6); g.fillStyle = s.dark ? '#1c1917' : '#fff'; g.fillText(s.t, w / 2, h / 2 + 6);
  });
}
const emojiBlob = (e) => canvasPng(256, 256, (g) => { g.font = '200px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(e, 128, 140); });

function wavBlob(samples, sr = 44100) {
  const n = samples.length, buf = new ArrayBuffer(44 + n * 2), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, clamp(samples[i], -1, 1) * 32767, true);
  return new Blob([buf], { type: 'audio/wav' });
}
const SFX = {
  whoosh: { name: 'Whoosh', make(sr) { const n = Math.floor(sr * 0.7), o = new Float32Array(n); let lp = 0, seed = 7; for (let i = 0; i < n; i++) { const t = i / n; seed = (seed * 16807) % 2147483647; const r = seed / 1073741823 - 1; const a = Math.sin(Math.PI * t) ** 1.5; const k = 0.04 + 0.5 * t; lp += k * (r - lp); o[i] = lp * a * 2.4; } return o; } },
  pop: { name: 'Pop', make(sr) { const n = Math.floor(sr * 0.18), o = new Float32Array(n); for (let i = 0; i < n; i++) { const t = i / sr; o[i] = Math.sin(2 * Math.PI * (900 - 4500 * t) * t) * Math.exp(-t * 28) * 0.9; } return o; } },
  ding: { name: 'Ding', make(sr) { const n = Math.floor(sr * 1.1), o = new Float32Array(n); for (let i = 0; i < n; i++) { const t = i / sr; o[i] = (Math.sin(2 * Math.PI * 1318 * t) + 0.4 * Math.sin(2 * Math.PI * 2636 * t)) * Math.exp(-t * 4.5) * 0.5; } return o; } },
  impact: { name: 'Impacto', make(sr) { const n = Math.floor(sr * 0.9), o = new Float32Array(n); let seed = 3; for (let i = 0; i < n; i++) { const t = i / sr; seed = (seed * 16807) % 2147483647; const nz = (seed / 1073741823 - 1) * Math.exp(-t * 30) * 0.5; o[i] = Math.tanh((Math.sin(2 * Math.PI * (70 - 35 * t) * t) * Math.exp(-t * 6) * 1.6) + nz); } return o; } },
  error: { name: 'Error', make(sr) { const n = Math.floor(sr * 0.45), o = new Float32Array(n); for (let i = 0; i < n; i++) { const t = i / sr; const f = t < 0.2 ? 220 : 165; const sq = Math.sign(Math.sin(2 * Math.PI * f * t)); o[i] = sq * 0.25 * (t < 0.2 ? 1 : Math.exp(-(t - 0.2) * 7)); } return o; } },
  tada: { name: 'Fanfarria', make(sr) { const notes = [523, 659, 784, 1047]; const n = Math.floor(sr * 1.3), o = new Float32Array(n); notes.forEach((f, k) => { const s0 = Math.floor(sr * (0.08 * k)); for (let i = s0; i < n; i++) { const t = (i - s0) / sr; o[i] += Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 3.2) * 0.22 * (k === 3 ? 1.3 : 1); } }); return o; } },
};

const uploadMedia = (pid, blob, name) => CZ.api.addMedia(pid, blob, name);

/* ------------------------------------------------------------------ */

window.EditorView = async function EditorView(app, pid, cid) {
  let P = await api(`/api/projects/${pid}`);
  let clip = P.clips.find((c) => c.id === cid);
  if (!clip) throw new Error('No se encontró el clip.');
  const S = P.source;
  let alive = true, tab = 'estilo', dirty = false, saveTimer, saving = false, needCaps = false;
  let playing = false, raf = 0, selOv = null, tlWin = null;
  const E = () => clip.edit;
  const dim = () => ({ '9:16': [9, 16], '16:9': [16, 9], '1:1': [1, 1] }[E().aspect]);
  const speed = () => clamp(Number(E().speed) || 1, 0.5, 2);
  const mediaById = (id) => P.media.find((m) => m.id === id);
  let MU = await CZ.api.mediaUrls(pid);
  const mediaUrl = (id) => MU[id] || '';
  const refreshMU = async () => { MU = await CZ.api.mediaUrls(pid); };
  await R.loadFonts();

  /* ---------- guardado automático ---------- */
  const setSave = (t) => { const el = $('#saveState'); if (el) el.textContent = t; };
  function touch(opts = {}) {
    dirty = true; if (opts.caps) needCaps = true;
    setSave('Guardando…');
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 600);
  }
  async function save() {
    if (saving) { saveTimer = setTimeout(save, 400); return; }
    if (!dirty) return;
    saving = true; dirty = false;
    const wantCaps = needCaps; needCaps = false;
    try {
      const res = await api(`/api/projects/${pid}/clips/${cid}`, { method: 'PUT', json: { title: clip.title, description: clip.description, start: clip.start, end: clip.end, edit: wantCaps ? { ...E(), captions: undefined } : E() } });
      if (wantCaps) { clip.edit.captions = res.edit.captions; if (tab === 'subs') renderPane(); }
      clip.start = res.start; clip.end = res.end;
      setSave('Guardado ✓');
    } catch (e) { dirty = true; setSave('Error al guardar'); fail(e); }
    saving = false;
    if (dirty) saveTimer = setTimeout(save, 600);
  }
  const flush = () => { clearTimeout(saveTimer); return dirty ? save() : Promise.resolve(); };

  /* ---------- layout ---------- */
  app.innerHTML = header(`<span class="small muted" id="saveState">Guardado ✓</span><a class="btn ghost sm" href="#/p/${pid}">${ic('back')} Clips</a>`) + `
  <div class="wrap"><div class="ed">
    <div class="left">
      <div class="stage-wrap"><div class="stage" id="stage"></div></div>
      <div class="ctrl"><button class="btn icon primary" id="play" aria-label="Reproducir">${ic('play')}</button><input type="range" id="seek" min="0" max="1000" value="0" aria-label="Posición"><span class="small muted" id="clock">0:00</span></div>
      <div class="row" style="margin-top:12px"><button class="btn primary" id="goExport" style="flex:1">${ic('download')} Exportar</button></div>
      <div class="hint" style="margin-top:8px">Lo que ves es lo que se exporta. La música y los efectos de sonido solo se oyen en el video exportado.</div>
    </div>
    <div class="right"><div class="card"><div class="body" style="padding-bottom:6px"><div class="row between"><b>Línea de tiempo</b><span class="small muted" id="tlInfo"></span></div><div class="tl" id="tl"></div>
      <div class="row small"><button class="btn sm" data-n="s-">−1 s inicio</button><button class="btn sm" data-n="s+">+1 s inicio</button><span class="spacer"></span><button class="btn sm" data-n="e-">−1 s final</button><button class="btn sm" data-n="e+">+1 s final</button></div></div></div>
      <div class="tabs" id="tabs" style="margin-top:12px"></div><div class="pane" id="pane"></div></div>
  </div></div>`;

  const TABS = [['estilo', 'wand', 'Estilos'], ['recorte', 'scissors', 'Recorte'], ['encuadre', 'crop', 'Encuadre'], ['subs', 'type', 'Subtítulos'], ['efectos', 'sliders', 'Efectos'], ['medios', 'image', 'Medios'], ['export', 'download', 'Exportar']];
  const tabsEl = $('#tabs');
  const drawTabs = () => { tabsEl.innerHTML = TABS.map(([k, i, n]) => `<button class="tab ${tab === k ? 'on' : ''}" data-t="${k}">${ic(i)} ${n}</button>`).join(''); };
  tabsEl.addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (b) { tab = b.dataset.t; drawTabs(); renderPane(); } });

  /* ---------- escenario (canvas, mismo motor que la exportación) ---------- */
  const stage = $('#stage');
  const vid = document.createElement('video');
  vid.src = P.sourceUrl; vid.preload = 'auto'; vid.playsInline = true; vid.muted = false;
  const cv = document.createElement('canvas'); cv.style.cssText = 'width:100%;height:100%;display:block;touch-action:none';
  stage.append(cv);
  const g = cv.getContext('2d');
  const medEls = new Map();
  const getMed = (id) => {
    const m = mediaById(id); if (!m) return null;
    let it = medEls.get(id);
    if (!it || it.url !== mediaUrl(id)) { it = { kind: m.kind, url: mediaUrl(id), el: R.makeMediaEl(m, mediaUrl(id)) }; medEls.set(id, it); }
    return it;
  };
  let SW = 360, SH = 640, W = 360, H = 640;
  function fitStage() {
    const [a, b] = dim();
    const maxW = Math.min(360, (stage.parentElement.clientWidth || 360) - 24);
    const maxH = Math.min(window.innerHeight * 0.62, 640);
    let w = maxW, h = (w * b) / a;
    if (h > maxH) { h = maxH; w = (h * a) / b; }
    SW = Math.round(w); SH = Math.round(h);
    stage.style.width = SW + 'px'; stage.style.height = SH + 'px';
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    W = Math.round(SW * dpr); H = Math.round(SH * dpr);
    cv.width = W; cv.height = H;
    layout();
  }
  function layout() {
    if (!vid.videoWidth) { g.fillStyle = '#000'; g.fillRect(0, 0, W, H); return; }
    vid.playbackRate = speed();
    const e = E();
    const split = e.framing === 'split' && e.splitMediaId && getMed(e.splitMediaId);
    if (split && split.kind !== 'image') { if (playing) split.el.play().catch(() => {}); else split.el.pause(); }
    const sel = selOv != null && e.overlays[selOv] ? e.overlays[selOv].id : null;
    R.drawFrame(g, W, H, { video: vid, sw: S.width, sh: S.height, e, start: clip.start, end: clip.end, t: clamp(vid.currentTime, clip.start, clip.end), media: getMed, showSel: sel });
  }
  const drawOverlays = () => layout();
  const prog = () => { const D = (clip.end - clip.start) / speed(); return clamp((vid.currentTime - clip.start) / speed() / Math.max(0.1, D), 0, 1); };

  // arrastrar sobre el escenario: mover una imagen o encuadrar el video
  function hitOverlay(px, py) {
    const e = E(); const D = (clip.end - clip.start) / speed();
    const t = (vid.currentTime - clip.start) / speed();
    for (let i = (e.overlays || []).length - 1; i >= 0; i--) {
      const o = e.overlays[i]; const m = getMed(o.mediaId); if (!m || m.kind !== 'image') continue;
      const a = o.start || 0, b = o.end == null ? D : o.end; if (t < a - 0.001 || t > b + 0.001) continue;
      const [ew, eh] = R.dims(m.el); if (!ew) continue;
      const r = R.overlayRect(o, W, H, ew, eh);
      if (px >= r.x && px <= r.x + r.w && py >= r.y && py <= r.y + r.h) return i;
    }
    return -1;
  }
  cv.addEventListener('pointerdown', (ev) => {
    ev.preventDefault();
    const r = cv.getBoundingClientRect(); const k = W / r.width;
    const hit = hitOverlay((ev.clientX - r.left) * k, (ev.clientY - r.top) * k);
    if (hit >= 0) {
      selOv = hit; const o = E().overlays[hit];
      const mv = (e2) => { o.x = clamp(((e2.clientX - r.left) / r.width) * 100, 0, 100); o.y = clamp(((e2.clientY - r.top) / r.height) * 100, 0, 100); layout(); };
      const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); touch(); if (tab === 'medios') renderPane(); };
      window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
      layout(); if (tab === 'medios') renderPane(); return;
    }
    if (E().framing === 'fit') return;
    const e = E(); const sx = ev.clientX, sy = ev.clientY, px0 = e.panX, py0 = e.panY;
    const topH = e.framing === 'split' ? SH / 2 : SH;
    const sc = Math.max(SW / S.width, topH / S.height) * e.zoom; const vw = S.width * sc, vh = S.height * sc;
    const mv = (e2) => {
      if (vw > SW + 1) e.panX = clamp(px0 - (e2.clientX - sx) / (vw - SW), 0, 1);
      if (vh > topH + 1) e.panY = clamp(py0 - (e2.clientY - sy) / (vh - topH), 0, 1);
      layout();
    };
    const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); touch(); if (tab === 'encuadre') renderPane(); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });

  /* reproducción */
  function loop() {
    if (!alive) return;
    if (playing) {
      if (vid.currentTime >= clip.end - 0.03 || vid.ended) vid.currentTime = clip.start;
      if (vid.currentTime < clip.start - 0.2) vid.currentTime = clip.start;
    }
    layout();
    updateClock();
    raf = requestAnimationFrame(loop);
  }
  function updateClock() {
    const D = (clip.end - clip.start) / speed();
    const t = clamp((vid.currentTime - clip.start) / speed(), 0, D);
    $('#clock').textContent = `${fmtMs(t)} / ${fmtMs(D)}`;
    $('#seek').value = Math.round((t / Math.max(0.1, D)) * 1000);
    const ph = $('#tl .ph'); if (ph && tlWin) ph.style.left = clamp(((vid.currentTime - tlWin[0]) / (tlWin[1] - tlWin[0])) * 100, 0, 100) + '%';
  }
  const setPlay = (v) => { playing = v; $('#play').innerHTML = ic(v ? 'pause' : 'play'); if (v) { if (vid.currentTime < clip.start || vid.currentTime >= clip.end - 0.1) vid.currentTime = clip.start; vid.play().catch(() => setPlay(false)); } else { vid.pause(); medEls.forEach((m) => m.kind !== 'image' && m.el.pause()); } };
  $('#play').onclick = () => setPlay(!playing);
  $('#seek').oninput = (e) => { const D = (clip.end - clip.start); vid.currentTime = clip.start + (e.target.value / 1000) * D; };
  vid.addEventListener('loadedmetadata', () => { vid.currentTime = clip.start; });

  /* ---------- línea de tiempo ---------- */
  function drawTimeline() {
    const dur = S.duration;
    const len = clip.end - clip.start;
    if (!tlWin) { const pad = Math.max(20, len * 0.8); tlWin = [Math.max(0, clip.start - pad), Math.min(dur, clip.end + pad)]; }
    const [a, b] = tlWin, W = b - a;
    const pct = (t) => ((t - a) / W) * 100;
    $('#tl').innerHTML = `<div class="sel" style="left:${pct(clip.start)}%;width:${pct(clip.end) - pct(clip.start)}%"></div><div class="h" data-h="s" style="left:${pct(clip.start)}%"></div><div class="h" data-h="e" style="left:${pct(clip.end)}%"></div><div class="ph"></div>
      <div class="small muted" style="position:absolute;left:8px;bottom:2px">${fmt(a)}</div><div class="small muted" style="position:absolute;right:8px;bottom:2px">${fmt(b)}</div>`;
    $('#tlInfo').textContent = `${fmt(clip.start)} → ${fmt(clip.end)} · ${Math.round(len)} s`;
  }
  $('#tl').addEventListener('pointerdown', (ev) => {
    const h = ev.target.closest('[data-h]'); const tl = $('#tl'); const r = tl.getBoundingClientRect();
    const tAt = (x) => tlWin[0] + clamp((x - r.left) / r.width, 0, 1) * (tlWin[1] - tlWin[0]);
    if (!h) { vid.currentTime = clamp(tAt(ev.clientX), clip.start, clip.end); return; }
    ev.preventDefault(); const which = h.dataset.h;
    const mv = (e2) => {
      const t = Math.round(tAt(e2.clientX) * 10) / 10;
      if (which === 's') clip.start = clamp(t, 0, clip.end - 5); else clip.end = clamp(t, clip.start + 5, S.duration);
      drawTimeline(); if (which === 's') vid.currentTime = clip.start; else vid.currentTime = Math.max(clip.start, clip.end - 1);
    };
    const up = () => { window.removeEventListener('pointermove', mv); window.removeEventListener('pointerup', up); touch({ caps: !E().captionsEdited }); if (tab === 'recorte') renderPane(); };
    window.addEventListener('pointermove', mv); window.addEventListener('pointerup', up);
  });
  app.addEventListener('click', (e) => {
    const b = e.target.closest('[data-n]'); if (!b) return;
    const k = b.dataset.n;
    if (k === 's-') clip.start = clamp(clip.start - 1, 0, clip.end - 5); if (k === 's+') clip.start = clamp(clip.start + 1, 0, clip.end - 5);
    if (k === 'e-') clip.end = clamp(clip.end - 1, clip.start + 5, S.duration); if (k === 'e+') clip.end = clamp(clip.end + 1, clip.start + 5, S.duration);
    tlWin = null; drawTimeline(); vid.currentTime = k[0] === 's' ? clip.start : Math.max(clip.start, clip.end - 1); touch({ caps: !E().captionsEdited }); if (tab === 'recorte') renderPane();
  });

  /* ---------- paneles ---------- */
  const pane = $('#pane');
  let paneClick = null;
  const slider = (label, key, min, max, step, get, set, fmtv = (v) => v) => `<label class="f">${label}<span class="v" data-v="${key}">${fmtv(get())}</span><input type="range" data-k="${key}" min="${min}" max="${max}" step="${step}" value="${get()}"></label>`;
  const btns = (key, opts, cur) => `<div class="chips" data-chips="${key}">${Object.entries(opts).map(([v, n]) => `<button class="opt ${String(cur) === v ? 'on' : ''}" data-val="${v}">${n}</button>`).join('')}</div>`;

  function renderPane() {
    const e = E(), s = e.subs;
    const hasTr = P.hasTranscript;
    if (tab === 'estilo') {
      pane.innerHTML = `<h3>Estilos de edición</h3><p class="muted small" style="margin:0">Cada estilo aplica de una vez subtítulos, zoom, filtro, marco y transiciones. Después podés ajustar todo a mano.</p>
      <div class="style-cards">${Object.entries(EDIT_STYLES).map(([k, v]) => `<button class="style-card ${e.styleId === k ? 'on' : ''}" data-style="${k}"><div class="sample" style="background:${v.grad}">${esc(v.name)}</div><b>${esc(v.name)}</b><div class="small muted">${esc(v.desc)}</div></button>`).join('')}</div>`;
      paneClick = (ev) => { const b = ev.target.closest('[data-style]'); if (!b) return; applyStyle(b.dataset.style); };
      return;
    }
    if (tab === 'recorte') {
      pane.innerHTML = `<h3>Recorte y tiempo</h3>
        <label class="f">Título<input type="text" id="ttl" value="${esc(clip.title)}" maxlength="90"></label>
        <label class="f">Descripción<textarea id="dsc" rows="2" maxlength="300">${esc(clip.description || '')}</textarea></label>
        <div class="fields"><label class="f">Inicio (m:ss)<input type="text" id="tS" value="${fmt(clip.start)}"></label><label class="f">Final (m:ss)<input type="text" id="tE" value="${fmt(clip.end)}"></label></div>
        <div class="hint">Arrastrá los bordes de la línea de tiempo o escribí los tiempos. Duración: ${Math.round(clip.end - clip.start)} s${clip.end - clip.start > 80 || clip.end - clip.start < 30 ? ' (fuera del rango sugerido de 30 s–1:20, podés exportarlo igual)' : ''}.</div>
        ${slider('Velocidad', 'speed', 0.5, 2, 0.05, () => e.speed, null, (v) => `${Number(v).toFixed(2)}×`)}
        <div class="fields"><div><div class="small muted" style="font-weight:600;margin-bottom:6px">Transición de entrada</div>${btns('transIn', TRANS, e.transIn)}</div><div><div class="small muted" style="font-weight:600;margin-bottom:6px">Transición de salida</div>${btns('transOut', TRANS, e.transOut)}</div></div>`;
      $('#ttl').oninput = (x) => { clip.title = x.target.value; touch(); };
      $('#dsc').oninput = (x) => { clip.description = x.target.value; touch(); };
      const tm = (id, key) => { $(id).onchange = (x) => { const v = parseT(x.target.value); if (v == null) return renderPane(); if (key === 's') clip.start = clamp(v, 0, clip.end - 5); else clip.end = clamp(v, clip.start + 5, S.duration); tlWin = null; drawTimeline(); vid.currentTime = clip.start; touch({ caps: !E().captionsEdited }); renderPane(); }; };
      tm('#tS', 's'); tm('#tE', 'e');
      bindGeneric(); return;
    }
    if (tab === 'encuadre') {
      const split = e.framing === 'split';
      pane.innerHTML = `<h3>Formato</h3>${btns('aspect', { '9:16': 'Vertical 9:16', '16:9': 'Horizontal 16:9', '1:1': 'Cuadrado 1:1' }, e.aspect)}
      <h3>Encuadre</h3>${btns('framing', { fill: 'Llenar (recorta)', fit: 'Entero con fondo difuso', split: 'Pantalla dividida' }, e.framing)}
      ${split ? `<div class="hint">${e.splitMediaId ? 'Abajo se muestra el archivo elegido en la pestaña Medios.' : 'Elegí un video o imagen para la mitad inferior en la pestaña Medios.'}</div>` : ''}
      ${e.framing !== 'fit' ? `<h3>Zoom</h3>${btns('zoomMode', { static: 'Zoom fijo', dynamic: 'Zoom automático (acerca o aleja durante el clip)' }, e.zoomMode)}
      ${slider(e.zoomMode === 'dynamic' ? 'Zoom inicial' : 'Zoom', 'zoom', 1, 3, 0.05, () => e.zoom, null, (v) => `${Number(v).toFixed(2)}×`)}
      ${e.zoomMode === 'dynamic' ? slider('Zoom final', 'zoomEnd', 1, 3, 0.05, () => e.zoomEnd, null, (v) => `${Number(v).toFixed(2)}×`) : ''}
      <h3>Posición del encuadre</h3><div class="hint">También podés arrastrar el video en la vista en vivo.</div>
      ${slider('Horizontal', 'panX', 0, 1, 0.01, () => e.panX, null, (v) => `${Math.round(v * 100)}%`)}
      ${slider('Vertical', 'panY', 0, 1, 0.01, () => e.panY, null, (v) => `${Math.round(v * 100)}%`)}
      <label class="check"><input type="checkbox" id="pan2" ${e.panX2 != null ? 'checked' : ''}> Mover el encuadre durante el clip (paneo horizontal)</label>
      ${e.panX2 != null ? slider('Horizontal al final', 'panX2', 0, 1, 0.01, () => e.panX2, null, (v) => `${Math.round(v * 100)}%`) : ''}
      <div class="hint">Seguimiento automático del hablante y reencuadre inteligente por rostros: todavía no disponibles (ver ayuda). Mientras tanto, usá posición fija o paneo.</div>` : '<div class="hint">En este modo el video se muestra completo, sobre un fondo difuso de sí mismo.</div>'}`;
      $('#pan2') && ($('#pan2').onchange = (x) => { e.panX2 = x.target.checked ? clamp(e.panX + 0.3, 0, 1) : null; touch(); renderPane(); });
      bindGeneric(); return;
    }
    if (tab === 'subs') {
      pane.innerHTML = `<label class="check"><input type="checkbox" id="subOn" ${s.on ? 'checked' : ''} ${hasTr ? '' : 'disabled'}> Mostrar subtítulos</label>
      ${hasTr ? '' : `<div class="banner" style="margin:0">${ic('alert')}<div class="small">Este proyecto no tiene transcripción, así que no hay subtítulos automáticos. Configurá un servicio de voz a texto en <a href="#/settings">Configuración</a> y volvé a analizar el video.${(e.captions || []).length ? '' : ''}</div></div>`}
      <h3>Estilos de subtítulos</h3><div class="style-cards">${Object.entries(SUB_PRESETS).map(([k, v]) => `<button class="style-card ${s.preset === k ? 'on' : ''}" data-sp="${k}"><div class="sample" style="${v.css}">${v.sample}</div><b class="small">${esc(v.name)}</b></button>`).join('')}</div>
      <h3>Personalizar</h3>
      <div class="fields"><label class="f">Tipografía<select data-k="subs.font">${FONTS.map((f) => `<option ${s.font === f ? 'selected' : ''}>${f}</option>`).join('')}</select></label>
      <label class="f">Animación<select data-k="subs.anim">${Object.entries(ANIMS).map(([v, n]) => `<option value="${v}" ${s.anim === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label></div>
      ${slider('Tamaño', 'subs.size', 2.5, 12, 0.1, () => s.size, null, (v) => `${Number(v).toFixed(1)}%`)}
      <div class="fields"><div><div class="small muted" style="font-weight:600;margin-bottom:6px">Posición</div>${btns('subs.pos', { top: 'Arriba', middle: 'Centro', bottom: 'Abajo' }, s.pos)}</div></div>
      ${slider('Distancia al borde', 'subs.marginV', 0, 50, 1, () => s.marginV, null, (v) => `${v}%`)}
      ${slider('Palabras por línea', 'subs.wordsPerLine', 1, 8, 1, () => s.wordsPerLine, null)}
      <div class="fields"><label class="f">Color<input type="color" data-k="subs.color" value="${s.color}"></label><label class="f">Palabra destacada<input type="color" data-k="subs.highlight" value="${s.highlight}"></label><label class="f">Contorno<input type="color" data-k="subs.outline" value="${s.outline}"></label></div>
      ${slider('Grosor del contorno', 'subs.outlineW', 0, 30, 1, () => s.outlineW, null)}
      ${slider('Sombra', 'subs.shadow', 0, 12, 1, () => s.shadow, null)}
      <div class="fields"><label class="check"><input type="checkbox" data-k="subs.highlightWords" ${s.highlightWords !== false ? 'checked' : ''}> Resaltar la palabra que se dice</label><label class="check"><input type="checkbox" data-k="subs.uppercase" ${s.uppercase ? 'checked' : ''}> MAYÚSCULAS</label><label class="check"><input type="checkbox" data-k="subs.bold" ${s.bold !== false ? 'checked' : ''}> Negrita</label><label class="check"><input type="checkbox" data-k="subs.box" ${s.box ? 'checked' : ''}> Caja de fondo</label></div>
      <h3>Texto de los subtítulos</h3>
      <div class="row"><button class="btn sm" id="regen" ${hasTr ? '' : 'disabled'}>${ic('refresh')} Regenerar desde la transcripción</button><button class="btn sm" id="addCap">${ic('plus')} Agregar línea aquí</button></div>
      <div class="caps" id="caps">${(e.captions || []).map((c) => `<div class="caprow" data-id="${c.id}"><time data-seek="${c.start}">${fmtMs(Math.max(0, (c.start - clip.start) / speed()))}</time><textarea rows="2" data-cap="${c.id}">${esc(c.text)}</textarea><button class="btn sm icon ghost danger" data-delcap="${c.id}" aria-label="Quitar">${ic('trash')}</button></div>`).join('') || '<div class="empty">No hay subtítulos en este rango.</div>'}</div>
      <div class="hint">Si cambiás el texto, las palabras se reparten dentro de la misma línea de tiempo del audio.</div>`;
      $('#subOn') && ($('#subOn').onchange = (x) => { s.on = x.target.checked; touch(); });
      paneClick = (ev) => {
        const sp = ev.target.closest('[data-sp]'); if (sp) { Object.assign(s, SUB_PRESETS[sp.dataset.sp].v, { preset: sp.dataset.sp }); touch(); renderPane(); return; }
        const sk = ev.target.closest('[data-seek]'); if (sk) { vid.currentTime = Number(sk.dataset.seek); return; }
        const dc = ev.target.closest('[data-delcap]'); if (dc) { e.captions = e.captions.filter((c) => c.id !== dc.dataset.delcap); e.captionsEdited = true; touch(); renderPane(); return; }
      };
      $('#regen').onclick = async () => { try { const r = await api(`/api/projects/${pid}/clips/${cid}/regen-captions`, { json: {} }); clip.edit.captions = r.edit.captions; clip.edit.captionsEdited = false; toast('Subtítulos regenerados', 'ok'); renderPane(); } catch (x) { fail(x); } };
      $('#addCap').onclick = () => { const t = clamp(vid.currentTime, clip.start, clip.end - 1); const id = Math.random().toString(16).slice(2, 8); e.captions.push({ id, start: t, end: t + 2, text: 'Nuevo texto', words: [{ w: 'Nuevo', s: t, e: t + 1 }, { w: 'texto', s: t + 1, e: t + 2 }] }); e.captions.sort((a, b) => a.start - b.start); e.captionsEdited = true; if (!s.on) s.on = true; touch(); renderPane(); };
      bindGeneric(); return;
    }
    if (tab === 'efectos') {
      const mus = P.media.filter((m) => m.kind === 'audio');
      pane.innerHTML = `<h3>Filtro de color</h3>${btns('filter', FILTER_NAMES, e.filter)}
      <h3>Marco decorativo</h3><label class="check"><input type="checkbox" id="bOn" ${e.border?.on ? 'checked' : ''}> Mostrar marco</label>
      ${e.border?.on ? `<div class="fields"><label class="f">Color<input type="color" data-k="border.color" value="${e.border.color}"></label>${slider('Grosor', 'border.width', 2, 60, 1, () => e.border.width, null)}</div>` : ''}
      <h3>Música de fondo</h3>
      ${mus.length ? `<label class="f">Pista<select id="musSel"><option value="">Sin música</option>${mus.filter((m) => !m.name.startsWith('sfx-')).map((m) => `<option value="${m.id}" ${e.music?.mediaId === m.id ? 'selected' : ''}>${esc(m.name)}</option>`).join('')}</select></label>` : ''}
      ${e.music ? slider('Volumen de la música', 'music.volume', 0, 1.5, 0.05, () => e.music.volume ?? 0.25, null, (v) => `${Math.round(v * 100)}%`) : ''}
      <div><button class="btn sm" id="upMus">${ic('upload')} Subir una canción o audio</button><input type="file" id="musFile" accept="audio/*" class="hidden"></div>
      <div class="hint">Clipazos no incluye música propia (por derechos de autor): subí una pista que tengas permiso de usar. Se repite si es más corta que el clip.</div>
      <h3>Efectos de sonido</h3>
      <div class="hint" style="margin:-6px 0 4px">Se agregan en el momento donde está la reproducción ahora (${fmtMs(clamp((vid.currentTime - clip.start) / speed(), 0, 1e6))}).</div>
      <div class="chips">${Object.entries(SFX).map(([k, v]) => `<button class="opt" data-sfx="${k}">${ic('plus')} ${v.name}</button>`).join('')}</div>
      <div class="caps" style="max-height:200px">${(e.sfx || []).map((f, i) => { const m = mediaById(f.mediaId); return `<div class="row between ovrow"><span>${esc(m?.name || '?').replace('sfx-', '')} · ${fmtMs(f.at)}</span><span class="row"><input type="range" min="0" max="2" step="0.05" value="${f.volume ?? 0.8}" data-sfxvol="${i}" style="width:110px" aria-label="Volumen"><button class="btn sm icon ghost danger" data-delsfx="${i}" aria-label="Quitar">${ic('trash')}</button></span></div>`; }).join('')}</div>
      <label class="check"><input type="checkbox" id="norm" ${e.normalize !== false ? 'checked' : ''}> Normalizar el volumen al exportar (recomendado)</label>`;
      $('#bOn').onchange = (x) => { e.border = { ...(e.border || { color: '#2f6bff', width: 12 }), on: x.target.checked }; touch(); renderPane(); };
      $('#norm').onchange = (x) => { e.normalize = x.target.checked; touch(); };
      $('#musSel') && ($('#musSel').onchange = (x) => { e.music = x.target.value ? { mediaId: x.target.value, volume: e.music?.volume ?? 0.25 } : null; touch(); renderPane(); });
      $('#upMus').onclick = () => $('#musFile').click();
      $('#musFile').onchange = async (x) => { const f = x.target.files[0]; if (!f) return; try { toast('Cargando audio…'); const m = await uploadMedia(pid, f, f.name); P.media.push(m); await refreshMU(); e.music = { mediaId: m.id, volume: 0.25 }; touch(); renderPane(); } catch (er) { fail(er); } };
      paneClick = async (ev) => {
        const sf = ev.target.closest('[data-sfx]'); if (sf) { await addSfx(sf.dataset.sfx); return; }
        const d = ev.target.closest('[data-delsfx]'); if (d) { e.sfx.splice(Number(d.dataset.delsfx), 1); touch(); renderPane(); }
      };
      bindGeneric(); return;
    }
    if (tab === 'medios') {
      const imgs = P.media.filter((m) => !m.name.startsWith('sfx-') && m.kind !== 'audio');
      const ovs = e.overlays || [];
      const D = (clip.end - clip.start) / speed();
      pane.innerHTML = `<h3>Stickers</h3><div class="chips">${STICKERS.map((st, i) => `<button class="opt" data-stk="${i}">${esc(st.t || (st.arrow === 'down' ? '⬇' : st.arrow === 'left' ? '⬅' : '➡'))}</button>`).join('')}</div>
      <h3>Emojis</h3><div class="emojis">${EMOJIS.map((em, i) => `<button data-emo="${i}" aria-label="Emoji ${em}">${em}</button>`).join('')}</div>
      <h3>Tus imágenes y videos</h3><div><button class="btn sm" id="upImg">${ic('upload')} Subir imagen o video</button><input type="file" id="imgFile" accept="image/*,video/*" class="hidden"></div>
      <div class="media-grid">${imgs.map((m) => `<div class="mi">${m.kind === 'image' ? `<img src="${mediaUrl(m.id)}" alt="">` : `<video src="${mediaUrl(m.id)}#t=0.1" muted preload="metadata"></video>`}<button class="btn sm icon x danger" data-delmedia="${m.id}" aria-label="Eliminar">${ic('x')}</button>
        ${m.kind === 'image' ? `<button class="btn sm use primary" data-useov="${m.id}">Agregar al clip</button>` : ''}<button class="btn sm use ${m.kind === 'image' ? '' : 'primary'}" style="${m.kind === 'image' ? 'bottom:34px' : ''}" data-usesplit="${m.id}">${e.splitMediaId === m.id ? '✓ Abajo' : 'Pantalla dividida'}</button></div>`).join('') || '<div class="empty" style="grid-column:1/-1">Todavía no subiste nada.</div>'}</div>
      <div class="hint">Las imágenes (y los stickers/emojis, que son imágenes) se superponen sobre el video. Los videos se usan en la pantalla dividida.</div>
      <h3>Elementos en este clip</h3>
      <div class="caps" style="max-height:none">${ovs.map((o, i) => { const m = mediaById(o.mediaId); return `<div class="ovrow ${selOv === i ? 'sel' : ''}" data-ov="${i}"><div class="row between"><b class="small">${esc(m?.name || 'Elemento')}</b><button class="btn sm icon ghost danger" data-delov="${i}" aria-label="Quitar">${ic('trash')}</button></div>
        <label class="f">Tamaño<span class="v">${Math.round(o.w)}%</span><input type="range" min="5" max="100" value="${o.w}" data-ovk="${i}.w"></label>
        <div class="fields"><label class="f">Aparece (s)<input type="number" min="0" max="${D.toFixed(1)}" step="0.1" value="${(o.start || 0).toFixed(1)}" data-ovk="${i}.start"></label><label class="f">Desaparece (s)<input type="number" min="0" max="${D.toFixed(1)}" step="0.1" value="${(o.end == null ? D : o.end).toFixed(1)}" data-ovk="${i}.end"></label></div></div>`; }).join('') || '<div class="empty">Tocá un sticker o emoji para agregarlo, y arrastralo en la vista en vivo.</div>'}</div>`;
      $('#upImg').onclick = () => $('#imgFile').click();
      $('#imgFile').onchange = async (x) => { const f = x.target.files[0]; if (!f) return; try { toast('Cargando…'); const m = await uploadMedia(pid, f, f.name); P.media.push(m); await refreshMU(); renderPane(); } catch (er) { fail(er); } };
      paneClick = async (ev) => {
        const st = ev.target.closest('[data-stk]'); if (st) { const s0 = STICKERS[Number(st.dataset.stk)]; await addOverlayFromBlob(`Sticker ${s0.n}.png`, () => stickerBlob(s0), s0.arrow ? 16 : 40); return; }
        const em = ev.target.closest('[data-emo]'); if (em) { const g = EMOJIS[Number(em.dataset.emo)]; await addOverlayFromBlob(`Emoji ${[...g].map((c) => c.codePointAt(0).toString(16)).join('-')}.png`, () => emojiBlob(g), 22); return; }
        const uo = ev.target.closest('[data-useov]'); if (uo) { addOverlay(uo.dataset.useov, 35); return; }
        const us = ev.target.closest('[data-usesplit]'); if (us) { e.splitMediaId = e.splitMediaId === us.dataset.usesplit ? null : us.dataset.usesplit; if (e.splitMediaId) e.framing = 'split'; else if (e.framing === 'split') e.framing = 'fill'; touch(); renderPane(); return; }
        const dm = ev.target.closest('[data-delmedia]'); if (dm) { if (await confirmBox('¿Eliminar este archivo?', 'Se quita también de todos los clips donde se use.', 'Eliminar')) { await api(`/api/projects/${pid}/media/${dm.dataset.delmedia}`, { method: 'DELETE' }).catch(fail); P = await api(`/api/projects/${pid}`); clip = P.clips.find((c) => c.id === cid); await refreshMU(); renderPane(); } return; }
        const dov = ev.target.closest('[data-delov]'); if (dov) { e.overlays.splice(Number(dov.dataset.delov), 1); selOv = null; touch(); renderPane(); return; }
        const row = ev.target.closest('[data-ov]'); if (row) { selOv = Number(row.dataset.ov); $$('.ovrow').forEach((r) => r.classList.toggle('sel', r === row)); }
      };
      return;
    }
    if (tab === 'export') {
      const exps = P.exports.filter((x) => x.clipId === cid);
      pane.innerHTML = `<h3>Exportar este clip</h3>
      <div><div class="small muted" style="font-weight:600;margin-bottom:6px">Formato</div>${btns('aspect', { '9:16': 'Vertical 9:16', '16:9': 'Horizontal 16:9', '1:1': 'Cuadrado 1:1' }, e.aspect)}</div>
      <div><div class="small muted" style="font-weight:600;margin-bottom:6px">Calidad (resolución del lado corto)</div>${btns('quality', { 720: '720p', 1080: '1080p' }, e.quality)}</div>
      <div class="hint">MP4 (H.264 + AAC), sin marca de agua. Se guarda en tu galería (Películas/Clipazos). La exportación se graba en tiempo real: dura lo mismo que el clip. <b>Dejá la app abierta y la pantalla encendida.</b> Tu video original es ${S.width}×${S.height}.</div>
      <div id="expState"></div><div class="row"><button class="btn primary" id="doExport" style="padding:14px 26px">${ic('download')} Exportar clip</button></div>
      ${exps.length ? `<h3>Exportaciones anteriores de este clip</h3><div class="caps" style="max-height:none">${exps.map((x) => `<div class="ovrow"><div class="row between"><span class="small">${x.aspect} · ${x.quality}p · ${bytes(x.size)} · ${new Date(x.createdAt).toLocaleString('es-AR')}</span><span class="row"><button class="btn sm primary" data-xo="${esc(x.uri)}" data-mime="${esc(x.mime || 'video/mp4')}">${ic('play')} Abrir</button><button class="btn sm" data-xs="${esc(x.uri)}" data-mime="${esc(x.mime || 'video/mp4')}">${ic('share')}</button></span></div></div>`).join('')}</div>` : ''}`;
      $('#doExport').onclick = doExport;
      paneClick = (ev) => { const o = ev.target.closest('[data-xo]'); if (o) return CZ.native.openUri(o.dataset.xo, o.dataset.mime); const sh = ev.target.closest('[data-xs]'); if (sh) CZ.native.share(sh.dataset.xs, sh.dataset.mime); };
      return;
    }
  }

  function chipClick(ev) {
    const b = ev.target.closest('[data-val]'); const wrap = ev.target.closest('[data-chips]'); if (!b || !wrap) return;
    setPath(wrap.dataset.chips, b.dataset.val);
    touch(); renderPane(); onEditChange(wrap.dataset.chips);
  }
  function setPath(path, val) {
    const parts = path.split('.'); let o = E(); for (let i = 0; i < parts.length - 1; i++) { o[parts[i]] = o[parts[i]] || {}; o = o[parts[i]]; }
    const last = parts[parts.length - 1]; const cur = o[last];
    o[last] = typeof cur === 'number' || ['quality', 'speed', 'zoom', 'zoomEnd', 'panX', 'panX2', 'panY'].includes(last) ? Number(val) : typeof cur === 'boolean' ? (val === true || val === 'true') : val;
    if (path === 'subs.pos' || path.startsWith('subs.')) E().subs.preset = E().subs.preset; // mantiene preset salvo cambios manuales
  }
  function onEditChange(path) { if (path === 'aspect') fitStage(); else layout(); }
  function bindGeneric() { /* los eventos del panel se registran una sola vez (masterInput / paneClick) */ }
  function masterInput(ev) {
    const t = ev.target;
    if (t.dataset.cap) return capInput(ev);
    if (t.dataset.sfxvol != null) { E().sfx[Number(t.dataset.sfxvol)].volume = Number(t.value); touch(); return; }
    if (t.dataset.ovk) {
      const [i, f] = t.dataset.ovk.split('.'); const o = E().overlays[Number(i)]; if (!o) return;
      o[f] = Number(t.value); if (f === 'w') t.parentElement.querySelector('.v').textContent = Math.round(o.w) + '%';
      touch(); drawOverlays(true); return;
    }
    const k = t.dataset.k; if (!k) return;
    const v = t.type === 'checkbox' ? t.checked : t.type === 'range' || t.type === 'number' ? Number(t.value) : t.value;
    setPath(k, v);
    const lab = pane.querySelector(`[data-v="${k}"]`);
    if (lab) lab.textContent = /zoom|^speed$/.test(k) ? `${Number(v).toFixed(2)}×` : /^pan/.test(k) ? `${Math.round(v * 100)}%` : k === 'subs.size' ? `${Number(v).toFixed(1)}%` : k === 'subs.marginV' ? `${v}%` : k === 'music.volume' ? `${Math.round(v * 100)}%` : v;
    touch(); layout();
    if (k === 'speed') drawTimeline();
  }
  function capInput(ev) {
    const id = ev.target.dataset.cap; if (!id) return;
    const c = E().captions.find((x) => x.id === id); if (!c) return;
    const toks = ev.target.value.trim().split(/\s+/).filter(Boolean);
    const old = c.words || [];
    if (toks.length === old.length) c.words = old.map((w, i) => ({ ...w, w: toks[i] }));
    else { const a = c.start, b = Math.max(c.end, c.start + 0.3), step = (b - a) / Math.max(1, toks.length); c.words = toks.map((w, i) => ({ w, s: a + i * step, e: a + (i + 1) * step })); }
    c.text = toks.join(' '); E().captionsEdited = true; touch(); drawCaption();
  }

  function applyStyle(k) {
    const st = EDIT_STYLES[k], e = E();
    const sp = SUB_PRESETS[st.e.sub];
    e.styleId = k; Object.assign(e.subs, sp.v, { preset: st.e.sub }, st.e.subOver || {});
    Object.assign(e, { zoomMode: st.e.zoomMode, zoom: st.e.zoom, filter: st.e.filter, transIn: st.e.transIn, transOut: st.e.transOut, framing: e.framing === 'split' ? 'split' : st.e.framing });
    if (st.e.zoomEnd) e.zoomEnd = st.e.zoomEnd;
    e.border = { ...(e.border || { color: '#2f6bff', width: 12 }), ...st.e.border };
    touch(); renderPane(); layout(); toast(`Estilo “${st.name}” aplicado`, 'ok');
  }

  async function ensureMedia(name, makeBlob) {
    const ex = P.media.find((m) => m.name === name.replace(/\.[^.]+$/, ''));
    if (ex) return ex;
    const m = await uploadMedia(pid, await makeBlob(), name); P.media.push(m); await refreshMU(); return m;
  }
  function addOverlay(mediaId, w) {
    const D = (clip.end - clip.start) / speed();
    const t = clamp((vid.currentTime - clip.start) / speed(), 0, D);
    E().overlays.push({ id: Math.random().toString(16).slice(2, 8), mediaId, x: 50, y: 40, w, start: Math.round(t * 10) / 10 > D - 1 ? 0 : Math.round(t * 10) / 10, end: null });
    selOv = E().overlays.length - 1; touch(); renderPane(); drawOverlays(); toast('Agregado: arrastralo en la vista en vivo para moverlo', 'ok');
  }
  async function addOverlayFromBlob(name, mk, w) { try { const m = await ensureMedia(name, mk); addOverlay(m.id, w); } catch (e) { fail(e); } }
  async function addSfx(k) {
    try {
      const m = await ensureMedia(`sfx-${SFX[k].name}.wav`, async () => wavBlob(SFX[k].make(44100)));
      const D = (clip.end - clip.start) / speed();
      E().sfx.push({ id: Math.random().toString(16).slice(2, 8), mediaId: m.id, at: Math.round(clamp((vid.currentTime - clip.start) / speed(), 0, D) * 10) / 10, volume: 0.8 });
      touch(); renderPane();
      const a = new Audio(URL.createObjectURL(wavBlob(SFX[k].make(44100)))); a.volume = 0.6; a.play().catch(() => {});
    } catch (e) { fail(e); }
  }

  /* ---------- vista previa real y exportación ---------- */
  async function runJob(kind, onProg) {
    await flush();
    const j = await api(`/api/projects/${pid}/clips/${cid}/${kind}`, { json: {} });
    let cur = j;
    while (alive && ['queued', 'running'].includes(cur.status)) {
      onProg && onProg(cur);
      await new Promise((r) => setTimeout(r, 500));
      cur = await api(`/api/jobs/${j.id}`);
    }
    return cur;
  }
  let exporting = false;
  async function doExport() {
    if (exporting) return; exporting = true;
    const box = $('#expState'); const btn = $('#doExport'); if (btn) btn.disabled = true;
    try {
      const j = await runJob('export', (c) => { if (box) box.innerHTML = `<div class="status-line" style="margin:6px 0"><span class="spin"></span><div style="flex:1"><div class="small">${c.status === 'queued' ? 'En cola…' : 'Exportando'} ${Math.round(c.progress * 100)}%</div><div class="bar" style="margin-top:6px"><i style="width:${Math.max(3, c.progress * 100)}%"></i></div></div></div>`; });
      if (j.status === 'done') {
        toast('Clip exportado', 'ok');
        P = await api(`/api/projects/${pid}`);
        if (tab === 'export') { renderPane(); const b2 = $('#expState'); if (b2) b2.innerHTML = `<div class="banner info" style="margin:6px 0">${ic('check')}<div><b>¡Listo! Guardado en Películas/Clipazos.</b> <button class="btn sm primary" id="xo">${ic('play')} Abrir</button> <button class="btn sm" id="xs">${ic('share')} Compartir</button></div></div>`; $('#xo').onclick = () => CZ.native.openUri(j.export.uri, j.export.mime); $('#xs').onclick = () => CZ.native.share(j.export.uri, j.export.mime); }
      } else if (j.status === 'error') { if (box) box.innerHTML = `<div class="banner bad" style="margin:6px 0">${ic('alert')}<div>${esc(j.error)}</div></div>`; }
    } catch (e) { fail(e); }
    exporting = false; if ($('#doExport')) $('#doExport').disabled = false;
  }
  $('#goExport').onclick = () => { tab = 'export'; drawTabs(); renderPane(); pane.scrollIntoView({ behavior: 'smooth', block: 'start' }); };

  /* ---------- arranque ---------- */
  const onResize = () => fitStage();
  window.addEventListener('resize', onResize);
  const onKey = (e) => { if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return; if (e.code === 'Space') { e.preventDefault(); setPlay(!playing); } };
  window.addEventListener('keydown', onKey);
  pane.addEventListener('click', (ev) => { if (ev.target.closest('[data-chips]')) return chipClick(ev); if (paneClick) paneClick(ev); });
  pane.addEventListener('input', masterInput);
  drawTabs(); renderPane(); drawTimeline(); fitStage();
  raf = requestAnimationFrame(loop);
  return () => { alive = false; cancelAnimationFrame(raf); clearTimeout(saveTimer); vid.pause(); vid.removeAttribute('src'); vid.load(); window.removeEventListener('resize', onResize); window.removeEventListener('keydown', onKey); if (dirty) flushSync(); };

  function flushSync() {
    // guarda lo pendiente al salir del editor
    api(`/api/projects/${pid}/clips/${cid}`, { method: 'PUT', json: { title: clip.title, description: clip.description, start: clip.start, end: clip.end, edit: E() } }).catch(() => {});
  }
};
})();
