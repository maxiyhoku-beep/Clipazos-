'use strict';
/* "Servidor" local: la misma API REST que usa la interfaz, pero resuelta dentro del teléfono
   (IndexedDB + puente nativo + motor de IA + render en canvas). No hay servidor ni PC. */
(() => {
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const num = (v, d) => (Number.isFinite(Number(v)) && v !== null && v !== '' ? Number(v) : d);
const rid = (n = 4) => [...crypto.getRandomValues(new Uint8Array(n))].map((b) => b.toString(16).padStart(2, '0')).join('');
const slug = (s) => String(s || 'clip').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'clip';
const E = CZ.engine;

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const notFound = (m = 'No encontrado') => new HttpError(404, m);

/* ---------- caché de proyectos y URLs de blobs ---------- */
const projects = new Map();
let loaded = null;
async function ensureLoaded() {
  if (!loaded) loaded = (async () => {
    for (const p of await CZ.db.all('projects')) {
      if (p.status === 'analyzing' || p.status === 'downloading') {
        p.status = p.source?.file ? 'uploaded' : 'error';
        p.analysis = { ...(p.analysis || {}), stage: 'error', error: 'El proceso se interrumpió porque se cerró la app. Volvé a intentarlo.' };
        await CZ.db.put('projects', p.id, p);
      }
      projects.set(p.id, p);
    }
  })();
  return loaded;
}
const getP = async (id) => { await ensureLoaded(); const p = projects.get(id); if (!p) throw notFound('Proyecto no encontrado'); return p; };
const saveP = async (p) => { p.updatedAt = Date.now(); await CZ.db.put('projects', p.id, p); };

const urlCache = new Map();
async function blobUrl(key) {
  if (urlCache.has(key)) return urlCache.get(key);
  const b = await CZ.db.get('blobs', key);
  if (!b) return null;
  const u = URL.createObjectURL(b); urlCache.set(key, u); return u;
}
async function putBlob(key, blob) {
  const old = urlCache.get(key); if (old) { URL.revokeObjectURL(old); urlCache.delete(key); }
  await CZ.db.put('blobs', key, blob);
}
async function delBlob(key) { const old = urlCache.get(key); if (old) { URL.revokeObjectURL(old); urlCache.delete(key); } await CZ.db.del('blobs', key); }

/* ---------- modelo de clip ---------- */
const DEFAULT_EDIT = () => ({
  styleId: 'viral', aspect: '9:16', quality: 720, framing: 'fill', panX: 0.5, panX2: null, panY: 0.5,
  zoom: 1, zoomMode: 'static', zoomEnd: 1.25, speed: 1, filter: 'none',
  border: { on: false, color: '#2f6bff', width: 12 }, transIn: 'none', transOut: 'none',
  subs: { on: true, preset: 'viral', font: 'Poppins', size: 5.2, pos: 'bottom', marginV: 20, color: '#ffffff', highlight: '#facc15', outline: '#000000', outlineW: 12, shadow: 3, bold: true, uppercase: true, wordsPerLine: 3, anim: 'pop', highlightWords: true, box: false },
  captions: [], captionsEdited: false, music: null, sfx: [], splitMediaId: null, overlays: [],
});
const transcriptCache = new Map();
async function loadTranscript(pid) {
  if (transcriptCache.has(pid)) return transcriptCache.get(pid);
  const t = (await CZ.db.get('transcripts', pid)) || null;
  transcriptCache.set(pid, t); return t;
}
function captionsFromTranscript(tr, start, end) {
  if (!tr || !tr.words?.length) return [];
  const words = tr.words.filter((w) => w.e > start && w.s < end).map((w) => ({ w: w.w, s: Math.max(w.s, start), e: Math.min(w.e, end) }));
  const caps = []; let cur = null;
  for (const w of words) {
    if (!cur || w.s - cur.words[cur.words.length - 1].e > 0.9 || cur.words.length >= 12 || /[.!?…]$/.test(cur.words[cur.words.length - 1].w)) { cur = { id: rid(3), start: w.s, end: w.e, text: '', words: [] }; caps.push(cur); }
    cur.words.push(w); cur.end = w.e;
  }
  for (const c of caps) c.text = c.words.map((w) => w.w).join(' ');
  return caps;
}
async function makeClip(p, base) {
  const tr = await loadTranscript(p.id);
  const clip = { id: rid(4), title: 'Clip', description: '', score: null, category: 'manual', reason: '', engine: 'manual', createdAt: Date.now(), ...base, edit: { ...DEFAULT_EDIT(), ...(base.edit || {}) } };
  if (!clip.edit.captions.length && tr) clip.edit.captions = captionsFromTranscript(tr, clip.start, clip.end);
  if (!tr) clip.edit.subs.on = false;
  return clip;
}
function sanitizeEdit(e, old) {
  const o = { ...(old || DEFAULT_EDIT()), ...e };
  o.aspect = ['9:16', '16:9', '1:1'].includes(o.aspect) ? o.aspect : '9:16';
  o.quality = [480, 720, 1080].includes(Number(o.quality)) ? Number(o.quality) : 720;
  o.framing = ['fill', 'fit', 'split'].includes(o.framing) ? o.framing : 'fill';
  o.zoom = clamp(num(o.zoom, 1), 1, 3); o.zoomEnd = clamp(num(o.zoomEnd, 1.25), 1, 3);
  o.zoomMode = o.zoomMode === 'dynamic' ? 'dynamic' : 'static';
  o.speed = clamp(num(o.speed, 1), 0.5, 2);
  o.panX = clamp(num(o.panX, 0.5), 0, 1); o.panX2 = o.panX2 === null || o.panX2 === '' || o.panX2 === undefined ? null : clamp(num(o.panX2, 0.5), 0, 1); o.panY = clamp(num(o.panY, 0.5), 0, 1);
  o.overlays = Array.isArray(o.overlays) ? o.overlays.slice(0, 30) : [];
  o.sfx = Array.isArray(o.sfx) ? o.sfx.slice(0, 20) : [];
  o.captions = Array.isArray(o.captions) ? o.captions : [];
  return o;
}

/* ---------- vista pública ---------- */
async function publicClip(p, c) { return { ...c, thumbUrl: (c.hasThumb && (await blobUrl(`${p.id}/clip/${c.id}`))) || (await blobUrl(`${p.id}/thumb`)) }; }
async function publicProject(p) {
  return { ...p, clips: await Promise.all(p.clips.map((c) => publicClip(p, c))), thumbUrl: await blobUrl(`${p.id}/thumb`), sourceUrl: `/media/${p.id}/source`, hasTranscript: !!p.hasTranscript };
}
const summary = async (p) => ({ id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt, status: p.status, duration: p.source?.duration || 0, width: p.source?.width, height: p.source?.height, size: p.source?.size, clipCount: p.clips.length, exportCount: p.exports.length, thumbUrl: await blobUrl(`${p.id}/thumb`) });

/* ---------- crear proyecto desde un video elegido en el teléfono ---------- */
async function createFromPick(pick) {
  const id = pick.id;
  const v = document.createElement('video');
  v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = `/media/${id}/source`;
  try {
    await CZ.render.waitEvent(v, 'loadeddata', 40000);
  } catch {
    CZ.native.deleteProject(id);
    throw new Error('Este teléfono no pudo abrir el video. Probá con un MP4 (H.264) o actualizá "Android System WebView".');
  }
  const duration = v.duration, w = v.videoWidth, h = v.videoHeight;
  if (!isFinite(duration) || !w) { CZ.native.deleteProject(id); throw new Error('El archivo no parece un video válido.'); }
  await CZ.render.seekTo(v, Math.min(duration * 0.1, 30)).catch(() => {});
  const c = document.createElement('canvas'); c.width = 480; c.height = Math.round((480 * h) / w);
  c.getContext('2d').drawImage(v, 0, 0, c.width, c.height);
  const thumb = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.8));
  v.removeAttribute('src'); v.load();
  await putBlob(`${id}/thumb`, thumb);
  const p = {
    id, name: String(pick.name || 'Video').replace(/\.[^.]+$/, '').slice(0, 100), createdAt: Date.now(), updatedAt: Date.now(), status: 'uploaded',
    source: { file: `source.${pick.ext || 'mp4'}`, originalName: pick.name, hasVideo: true, hasAudio: true, duration, width: w, height: h, fps: 30, size: pick.size || 0 },
    clips: [], media: [], exports: [], analysis: null, settings: { count: 5, minDur: 30, maxDur: 80 }, hasTranscript: false,
  };
  await ensureLoaded(); projects.set(id, p); await saveP(p);
  return publicProject(p);
}

/* ---------- análisis ---------- */
const analysisJobs = new Map();
function setStage(p, stage, progress, message, save = false) { p.analysis = { ...(p.analysis || {}), stage, progress, message }; if (save) saveP(p); }

async function ensureClipThumbs(p, onProgress) {
  const todo = p.clips.filter((c) => !c.hasThumb);
  if (!todo.length) return;
  const v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = `/media/${p.id}/source`;
  try {
    await CZ.render.waitEvent(v, 'loadeddata', 30000);
    let i = 0;
    for (const c of todo) {
      try {
        await CZ.render.seekTo(v, c.start + Math.min(2, (c.end - c.start) / 4));
        const cv = document.createElement('canvas'); cv.width = 400; cv.height = 225;
        const g = cv.getContext('2d'); g.fillStyle = '#000'; g.fillRect(0, 0, 400, 225);
        const s = Math.min(400 / v.videoWidth, 225 / v.videoHeight); g.drawImage(v, (400 - v.videoWidth * s) / 2, (225 - v.videoHeight * s) / 2, v.videoWidth * s, v.videoHeight * s);
        const b = await new Promise((r) => cv.toBlob(r, 'image/jpeg', 0.75));
        await putBlob(`${p.id}/clip/${c.id}`, b); c.hasThumb = true;
      } catch {}
      onProgress && onProgress(++i / todo.length);
    }
  } catch {} finally { v.removeAttribute('src'); v.load(); }
}

async function runAnalysis(p, params) {
  const ac = { aborted: false }; analysisJobs.set(p.id, ac);
  const signal = { get aborted() { return ac.aborted; } };
  p.status = 'analyzing';
  p.analysis = { params, startedAt: Date.now(), stage: 'audio', progress: 0, message: 'Extrayendo el audio del video y midiendo su energía…', warnings: [] };
  await saveP(p);
  CZ.native.keepAwake(true);
  try {
    const res = await CZ.native.analyzeAudio(p.id, (a, b) => setStage(p, 'audio', b ? a / b : a, 'Extrayendo el audio del video y midiendo su energía…'));
    if (ac.aborted) throw E.abortErr();
    if (!res || res.error) throw new Error(res?.error || 'No se pudo leer el audio del video.');
    if (!res.hasAudio) throw new Error('El video no tiene pista de audio, no se puede analizar.');
    p.source.hasAudio = true;
    if (res.duration > 1 && Math.abs(res.duration - p.source.duration) > 2) p.source.duration = Math.max(p.source.duration, res.duration);
    const settings = await E.getSettings();
    let transcript = null;
    setStage(p, 'transcribe', 0, 'La IA está transcribiendo lo que se dice en el video…', true);
    if (settings.transcribe.key) {
      transcript = await E.transcribeChunks(p.id, res.chunks, settings, params.language, { signal, onProgress: (f) => setStage(p, 'transcribe', f, 'La IA está transcribiendo lo que se dice en el video…') });
    }
    if (transcript) { await CZ.db.put('transcripts', p.id, transcript); transcriptCache.set(p.id, transcript); p.hasTranscript = true; }
    else { await CZ.db.del('transcripts', p.id); transcriptCache.delete(p.id); p.hasTranscript = false; }

    setStage(p, 'select', 0, transcript ? 'Buscando los momentos con más potencial: humor, reacciones, frases y giros…' : 'Buscando los picos de energía del audio…', true);
    const sel = await E.selectClips({ transcript, energy: res.energy, duration: p.source.duration, count: params.count, minDur: params.minDur, maxDur: params.maxDur, settings, signal, onProgress: (f) => setStage(p, 'select', f, 'Buscando los momentos con más potencial: humor, reacciones, frases y giros…') });
    setStage(p, 'finish', 0.1, 'Preparando los clips, subtítulos y miniaturas…');
    for (const c of p.clips.filter((x) => x.engine !== 'manual')) await delBlob(`${p.id}/clip/${c.id}`);
    p.clips = p.clips.filter((c) => c.engine === 'manual');
    for (const c of sel.clips) p.clips.push(await makeClip(p, { start: Math.round(c.start * 100) / 100, end: Math.round(c.end * 100) / 100, score: c.score, title: c.title, description: c.description, category: c.category, reason: c.reason, engine: c.engine }));
    await ensureClipThumbs(p, (f) => setStage(p, 'finish', 0.1 + 0.85 * f, 'Preparando los clips, subtítulos y miniaturas…'));
    p.status = 'ready';
    p.analysis = { ...p.analysis, stage: 'done', progress: 1, message: 'Listo', warnings: sel.warnings, engine: sel.engine, transcribed: !!transcript, finishedAt: Date.now() };
  } catch (e) {
    p.status = 'uploaded';
    p.analysis = e.code === 'ABORT' || ac.aborted ? { ...p.analysis, stage: 'canceled', message: 'Análisis cancelado', error: null } : { ...p.analysis, stage: 'error', error: e.message || String(e), message: 'Falló el análisis' };
  } finally {
    analysisJobs.delete(p.id); CZ.native.keepAwake(false);
    await saveP(p);
  }
}

/* ---------- renders (exportación) ---------- */
const jobs = new Map(); const queue = []; let pumping = false;
const jobView = (j) => ({ id: j.id, pid: j.pid, cid: j.cid, kind: j.kind, status: j.status, progress: j.progress, message: j.message, error: j.error, export: j.export });
const newJob = (pid, cid) => ({ id: rid(5), pid, cid, kind: 'export', status: 'queued', progress: 0, message: 'En cola…', abort: { aborted: false } });
function enqueue(job) { jobs.set(job.id, job); queue.push(job); pump(); return job; }
async function pump() {
  if (pumping) return; pumping = true;
  while (queue.length) { const j = queue.shift(); if (j.status === 'canceled') continue; await runRender(j); }
  pumping = false; CZ.native.keepAwake(false);
}
async function runRender(job) {
  let p, clip;
  try { p = await getP(job.pid); clip = p.clips.find((c) => c.id === job.cid); } catch {}
  if (!p || !clip) { job.status = 'error'; job.error = 'El clip ya no existe'; return; }
  job.status = 'running'; job.message = 'Exportando el clip…';
  CZ.native.keepAwake(true);
  try {
    const e = sanitizeEdit(clip.edit, clip.edit);
    const media = [];
    for (const m of p.media) media.push({ id: m.id, kind: m.kind, url: await blobUrl(`${p.id}/media/${m.id}`) });
    const r = await CZ.render.exportClip({ source: { url: `/media/${p.id}/source`, width: p.source.width, height: p.source.height }, clip: { ...clip, edit: e }, media, onProgress: (f) => { job.progress = f * 0.95; }, signal: job.abort });
    job.message = 'Guardando en la galería…';
    const name = `${slug(p.name)}_${slug(clip.title)}_${e.aspect.replace(':', 'x')}_${e.quality}p_${Date.now()}.${r.ext}`;
    const saved = await CZ.native.saveVideo(r.blob, name, r.mime, (f) => { job.progress = 0.95 + 0.05 * f; });
    const rec = { id: rid(4), clipId: clip.id, clipTitle: clip.title, file: saved.name || name, uri: saved.uri, size: saved.size || r.blob.size, createdAt: Date.now(), aspect: e.aspect, quality: e.quality, duration: r.duration, mime: r.mime };
    const pp = await getP(p.id).catch(() => null);
    if (pp) { pp.exports.unshift(rec); await saveP(pp); }
    job.progress = 1; job.status = 'done'; job.message = 'Listo'; job.export = rec;
  } catch (err) {
    if (err.code === 'ABORT') { job.status = 'canceled'; job.message = 'Cancelado'; } else { job.status = 'error'; job.error = err.message || String(err); job.message = 'Falló'; }
  } finally { setTimeout(() => jobs.delete(job.id), 3600e3); }
}

/* ---------- medios del proyecto (imágenes, audios, videos) ---------- */
const IMAGE_EXT = /\.(png|jpe?g|webp|gif)$/i, AUDIO_EXT = /\.(mp3|wav|m4a|aac|ogg|flac)$/i, VIDEO_EXT = /\.(mp4|mov|mkv|webm|avi|m4v|3gp)$/i;
async function probeMedia(blob, kind) {
  const url = URL.createObjectURL(blob);
  try {
    if (kind === 'image') { const im = new Image(); im.src = url; await im.decode(); return { width: im.naturalWidth, height: im.naturalHeight }; }
    const el = document.createElement(kind === 'video' ? 'video' : 'audio'); el.preload = 'metadata'; el.src = url;
    await CZ.render.waitEvent(el, 'loadedmetadata', 15000);
    return { width: el.videoWidth, height: el.videoHeight, duration: el.duration };
  } catch { return {}; } finally { URL.revokeObjectURL(url); }
}
async function addMedia(pid, blob, name) {
  const p = await getP(pid);
  const kind = VIDEO_EXT.test(name) || (blob.type || '').startsWith('video/') ? 'video' : IMAGE_EXT.test(name) || (blob.type || '').startsWith('image/') ? 'image' : AUDIO_EXT.test(name) || (blob.type || '').startsWith('audio/') ? 'audio' : null;
  if (!kind) throw new Error('Formato no compatible (imágenes PNG/JPG/WebP/GIF, audios MP3/WAV/M4A, videos MP4/WebM).');
  if (blob.size > 500 * 1024 * 1024) throw new Error('El archivo es demasiado grande (máximo 500 MB).');
  const id = rid(4);
  const info = await probeMedia(blob, kind);
  if (kind !== 'audio' && !info.width) throw new Error('No se pudo leer el archivo.');
  await putBlob(`${pid}/media/${id}`, blob);
  const item = { id, name: name.replace(/\.[^.]+$/, ''), kind, file: name, info };
  p.media.push(item); await saveP(p);
  return item;
}
async function mediaUrls(pid) { const p = await getP(pid); const out = {}; for (const m of p.media) out[m.id] = await blobUrl(`${pid}/media/${m.id}`); return out; }

/* ---------- rutas ---------- */
const routes = [];
const route = (method, re, fn) => routes.push({ method, re, fn });
const P = '^/api/projects/([A-Za-z0-9_-]+)';

route('GET', /^\/api\/status$/, async () => {
  const s = await E.getSettings();
  return { ffmpeg: true, ytdlp: false, native: CZ.native.available, transcription: s.transcribe.key ? 'api' : null, transcriptionModel: s.transcribe.model, llm: !!s.llm.key, llmModel: s.llm.key ? s.llm.model : null, version: '2.0.0' };
});
route('GET', /^\/api\/settings$/, () => E.getSettings());
route('PUT', /^\/api\/settings$/, async (m, b) => {
  const patch = {};
  if (typeof b.language === 'string' && /^(auto|[a-z]{2})$/.test(b.language)) patch.language = b.language;
  for (const k of ['transcribe', 'llm']) if (b[k] && typeof b[k] === 'object') { patch[k] = {}; for (const f of ['key', 'baseUrl', 'model']) if (typeof b[k][f] === 'string') patch[k][f] = b[k][f].trim(); }
  return E.saveSettings(patch);
});
route('GET', /^\/api\/projects$/, async () => { await ensureLoaded(); return Promise.all([...projects.values()].sort((a, b) => b.updatedAt - a.updatedAt).map(summary)); });
route('GET', /^\/api\/exports$/, async () => {
  await ensureLoaded(); const out = [];
  for (const p of projects.values()) for (const x of p.exports) out.push({ ...x, projectId: p.id, projectName: p.name, thumbUrl: await blobUrl(`${p.id}/thumb`) });
  return out.sort((a, b) => b.createdAt - a.createdAt).slice(0, 60);
});
route('GET', new RegExp(`${P}$`), async (m) => publicProject(await getP(m[1])));
route('PATCH', new RegExp(`${P}$`), async (m, b) => {
  const p = await getP(m[1]);
  if (typeof b.name === 'string' && b.name.trim()) p.name = b.name.trim().slice(0, 100);
  if (b.settings && typeof b.settings === 'object') {
    p.settings = { count: clamp(Math.round(num(b.settings.count, 5)), 1, 40), minDur: clamp(Math.round(num(b.settings.minDur, 30)), 30, 80), maxDur: clamp(Math.round(num(b.settings.maxDur, 80)), 30, 80) };
    if (p.settings.maxDur < p.settings.minDur) p.settings.maxDur = p.settings.minDur;
  }
  await saveP(p); return publicProject(p);
});
route('DELETE', new RegExp(`${P}$`), async (m) => {
  const p = await getP(m[1]);
  const a = analysisJobs.get(p.id); if (a) { a.aborted = true; CZ.native.cancelAnalysis(p.id); }
  for (const j of jobs.values()) if (j.pid === p.id) j.abort.aborted = true;
  projects.delete(p.id); transcriptCache.delete(p.id);
  await CZ.db.del('projects', p.id); await CZ.db.del('transcripts', p.id);
  for (const k of [...urlCache.keys()]) if (k.startsWith(p.id + '/')) { URL.revokeObjectURL(urlCache.get(k)); urlCache.delete(k); }
  await CZ.db.delPrefix('blobs', p.id + '/');
  CZ.native.deleteProject(p.id);
  return { ok: true };
});
route('POST', new RegExp(`${P}/analyze$`), async (m, b) => {
  const p = await getP(m[1]);
  if (p.status === 'analyzing') throw new HttpError(409, 'Ya se está analizando.');
  const count = clamp(Math.round(num(b.count, 5)), 1, 40);
  const minDur = clamp(Math.round(num(b.minDur, 30)), 30, 80), maxDur = clamp(Math.round(num(b.maxDur, 80)), minDur, 80);
  const language = typeof b.language === 'string' ? b.language : (await E.getSettings()).language;
  if (p.source.duration < minDur) throw new HttpError(400, `El video dura menos que el mínimo de ${minDur} segundos.`);
  p.settings = { count, minDur, maxDur };
  runAnalysis(p, { count, minDur, maxDur, language });
  return { ok: true };
});
route('POST', new RegExp(`${P}/cancel$`), async (m) => { const a = analysisJobs.get(m[1]); if (a) { a.aborted = true; CZ.native.cancelAnalysis(m[1]); } return { ok: true }; });
route('POST', new RegExp(`${P}/clips$`), async (m, b) => {
  const p = await getP(m[1]); const dur = p.source.duration;
  const start = clamp(num(b.start, 0), 0, Math.max(0, dur - 5)), end = clamp(num(b.end, start + 45), start + 3, dur);
  const clip = await makeClip(p, { start, end, title: String(b.title || 'Clip manual').slice(0, 90), engine: 'manual', category: 'manual' });
  p.clips.push(clip); await saveP(p); return clip;
});
route('PUT', new RegExp(`${P}/clips/([A-Za-z0-9_-]+)$`), async (m, b) => {
  const p = await getP(m[1]); const clip = p.clips.find((c) => c.id === m[2]); if (!clip) throw notFound('Clip no encontrado');
  const dur = p.source.duration; let regen = false;
  if (b.title !== undefined) clip.title = String(b.title).slice(0, 90);
  if (b.description !== undefined) clip.description = String(b.description).slice(0, 300);
  if (b.start !== undefined || b.end !== undefined) {
    const s = clamp(num(b.start, clip.start), 0, dur - 1), e = clamp(num(b.end, clip.end), s + 1, dur);
    if (Math.abs(s - clip.start) > 0.001 || Math.abs(e - clip.end) > 0.001) regen = true;
    clip.start = Math.round(s * 100) / 100; clip.end = Math.round(e * 100) / 100;
  }
  if (b.edit) clip.edit = sanitizeEdit({ ...clip.edit, ...b.edit }, clip.edit);
  if (regen && !clip.edit.captionsEdited) { const tr = await loadTranscript(p.id); if (tr) clip.edit.captions = captionsFromTranscript(tr, clip.start, clip.end); }
  await saveP(p); return clip;
});
route('POST', new RegExp(`${P}/clips/([A-Za-z0-9_-]+)/regen-captions$`), async (m) => {
  const p = await getP(m[1]); const clip = p.clips.find((c) => c.id === m[2]); if (!clip) throw notFound('Clip no encontrado');
  const tr = await loadTranscript(p.id); if (!tr) throw new HttpError(400, 'Este proyecto no tiene transcripción.');
  clip.edit.captions = captionsFromTranscript(tr, clip.start, clip.end); clip.edit.captionsEdited = false; await saveP(p); return clip;
});
route('POST', new RegExp(`${P}/clips/([A-Za-z0-9_-]+)/duplicate$`), async (m) => {
  const p = await getP(m[1]); const clip = p.clips.find((c) => c.id === m[2]); if (!clip) throw notFound('Clip no encontrado');
  const copy = JSON.parse(JSON.stringify(clip)); copy.id = rid(4); copy.title = `${clip.title} (copia)`.slice(0, 90); copy.createdAt = Date.now(); copy.hasThumb = false;
  p.clips.splice(p.clips.indexOf(clip) + 1, 0, copy); await saveP(p); return copy;
});
route('DELETE', new RegExp(`${P}/clips/([A-Za-z0-9_-]+)$`), async (m) => {
  const p = await getP(m[1]); const i = p.clips.findIndex((c) => c.id === m[2]); if (i < 0) throw notFound('Clip no encontrado');
  await delBlob(`${p.id}/clip/${p.clips[i].id}`); p.clips.splice(i, 1); await saveP(p); return { ok: true };
});
route('DELETE', new RegExp(`${P}/media/([A-Za-z0-9_-]+)$`), async (m) => {
  const p = await getP(m[1]); const i = p.media.findIndex((x) => x.id === m[2]); if (i < 0) throw notFound('Archivo no encontrado');
  const [it] = p.media.splice(i, 1);
  for (const c of p.clips) { const e = c.edit; e.overlays = e.overlays.filter((o) => o.mediaId !== it.id); e.sfx = (e.sfx || []).filter((o) => o.mediaId !== it.id); if (e.music?.mediaId === it.id) e.music = null; if (e.splitMediaId === it.id) e.splitMediaId = null; }
  await delBlob(`${p.id}/media/${it.id}`); await saveP(p); return { ok: true };
});
route('DELETE', new RegExp(`${P}/exports/([A-Za-z0-9_-]+)$`), async (m) => {
  const p = await getP(m[1]); const i = p.exports.findIndex((x) => x.id === m[2]); if (i < 0) throw notFound('Exportación no encontrada');
  const [ex] = p.exports.splice(i, 1); if (ex.uri) await CZ.native.deleteUri(ex.uri); await saveP(p); return { ok: true };
});
route('POST', new RegExp(`${P}/clips/([A-Za-z0-9_-]+)/export$`), async (m) => {
  const p = await getP(m[1]); if (!p.clips.find((c) => c.id === m[2])) throw notFound('Clip no encontrado');
  return jobView(enqueue(newJob(p.id, m[2])));
});
route('POST', new RegExp(`${P}/export-all$`), async (m) => { const p = await getP(m[1]); return p.clips.map((c) => jobView(enqueue(newJob(p.id, c.id)))); });
route('GET', /^\/api\/jobs\/([A-Za-z0-9_-]+)$/, async (m) => { const j = jobs.get(m[1]); if (!j) throw notFound('Tarea no encontrada'); return jobView(j); });
route('POST', /^\/api\/jobs\/([A-Za-z0-9_-]+)\/cancel$/, async (m) => { const j = jobs.get(m[1]); if (!j) throw notFound('Tarea no encontrada'); j.abort.aborted = true; if (j.status === 'queued') { j.status = 'canceled'; j.message = 'Cancelado'; } return jobView(j); });
route('POST', /^\/api\/jobs\/query$/, async (m, b) => (b.ids || []).map((id) => jobs.get(id)).filter(Boolean).map(jobView));

async function request(method, path, body) {
  const url = new URL(path, 'http://local');
  for (const r of routes) {
    if (r.method !== method) continue;
    const m = r.re.exec(url.pathname);
    if (m) { const out = await r.fn(m, body || {}, url); return out === undefined ? { ok: true } : JSON.parse(JSON.stringify(out)); }
  }
  throw notFound('Ruta no encontrada');
}

CZ.api = { request, createFromPick, addMedia, mediaUrls, blobUrl, DEFAULT_EDIT, sanitizeEdit };
})();
