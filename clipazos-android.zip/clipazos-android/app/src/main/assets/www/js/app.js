'use strict';
/* Clipazos – interfaz (JS plano, sin dependencias). Vistas: inicio, proyecto, editor (editor.js), ajustes, ayuda. */

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const fmt = (s) => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
const fmtMs = (s) => { s = Math.max(0, s); const m = Math.floor(s / 60); return `${m}:${(s - m * 60).toFixed(1).padStart(4, '0')}`; };
const parseT = (str) => { const p = String(str).trim().split(':').map(Number); if (p.some((n) => !Number.isFinite(n))) return null; return p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p.length === 2 ? p[0] * 60 + p[1] : p[0]; };
const bytes = (n) => (n > 1e9 ? (n / 1e9).toFixed(2) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1e3)) + ' KB');
const ago = (ts) => { const d = (Date.now() - ts) / 1000; if (d < 60) return 'ahora'; if (d < 3600) return `hace ${Math.floor(d / 60)} min`; if (d < 86400) return `hace ${Math.floor(d / 3600)} h`; return `hace ${Math.floor(d / 86400)} d`; };

const ICONS = {
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>', link: '<path d="M10 14a4 4 0 0 0 5.6 0l3-3a4 4 0 0 0-5.6-5.6l-1 1M14 10a4 4 0 0 0-5.6 0l-3 3a4 4 0 0 0 5.6 5.6l1-1"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>', trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/>',
  copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>', download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>', edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  spark: '<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>', play: '<path d="M6 4l14 8-14 8z" fill="currentColor"/>',
  pause: '<path d="M7 4h4v16H7zM13 4h4v16h-4z" fill="currentColor"/>', back: '<path d="M15 18l-6-6 6-6"/>', x: '<path d="M18 6L6 18M6 6l12 12"/>', plus: '<path d="M12 5v14M5 12h14"/>',
  scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12"/>', crop: '<path d="M6 2v14a2 2 0 0 0 2 2h14M2 6h14a2 2 0 0 1 2 2v14"/>',
  type: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>', wand: '<path d="M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M17.8 6.2L19 5M3 21l9-9M12.2 6.2L11 5"/>', film: '<rect x="2" y="3" width="20" height="18" rx="2"/><path d="M7 3v18M17 3v18M2 8h5M2 16h5M17 8h5M17 16h5"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>', check: '<path d="M20 6L9 17l-5-5"/>', alert: '<path d="M12 9v4M12 17h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>', share: '<path d="M4 12v8h16v-8M12 3v13M8 7l4-4 4 4"/>', sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>', refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5"/>',
};
const ic = (n, cls = '') => `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;
const LOGO = `<svg class="logo" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2f6bff"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#lg)"/><path d="M24 17v30l24-15z" fill="#fff"/><path d="M48 9l2 6 6 2-6 2-2 6-2-6-6-2 6-2z" fill="#22d3ee"/></svg>`;

async function api(path, opts = {}) {
  const method = opts.method || (opts.json !== undefined ? 'POST' : 'GET');
  return CZ.api.request(method, path, opts.json);
}
function toast(msg, type = '') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  $('#toasts').append(el);
  setTimeout(() => el.remove(), type === 'bad' ? 7000 : 3500);
}
const fail = (e) => toast(e.message || String(e), 'bad');

function modal(html, { wide, onClose } = {}) {
  const m = document.createElement('div');
  m.className = 'modal';
  m.innerHTML = `<div class="box ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
  const close = () => { m.remove(); onClose && onClose(); };
  m.addEventListener('mousedown', (e) => { if (e.target === m) close(); });
  document.body.append(m);
  m.close = close;
  return m;
}
function confirmBox(title, text, okLabel = 'Eliminar') {
  return new Promise((resolve) => {
    const m = modal(`<h3>${esc(title)}</h3><p class="muted">${esc(text)}</p><div class="row" style="justify-content:flex-end;margin-top:16px"><button class="btn ghost" data-r="0">Cancelar</button><button class="btn danger" data-r="1">${esc(okLabel)}</button></div>`, { onClose: () => resolve(false) });
    m.addEventListener('click', (e) => { const b = e.target.closest('[data-r]'); if (b) { const v = b.dataset.r === '1'; m.remove(); resolve(v); } });
  });
}
function promptBox(title, value) {
  return new Promise((resolve) => {
    const m = modal(`<h3>${esc(title)}</h3><input type="text" value="${esc(value)}" maxlength="100" style="margin-top:12px"><div class="row" style="justify-content:flex-end;margin-top:16px"><button class="btn ghost" data-r="0">Cancelar</button><button class="btn primary" data-r="1">Guardar</button></div>`, { onClose: () => resolve(null) });
    const inp = $('input', m); inp.focus(); inp.select();
    const done = () => { const v = inp.value.trim(); m.remove(); resolve(v || null); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(); });
    m.addEventListener('click', (e) => { const b = e.target.closest('[data-r]'); if (b) { if (b.dataset.r === '1') done(); else { m.remove(); resolve(null); } } });
  });
}

/* ------------------------------------------------------------------ */
/* Estado global                                                        */
/* ------------------------------------------------------------------ */

const G = { status: null, settings: { language: 'auto' }, upload: null, cleanup: null };

function header(extra = '') {
  return `<header class="top"><a class="brand" href="#/">${LOGO}<b>Clipazos</b></a><div class="spacer"></div>${extra}
    <a class="btn ghost sm" href="#/help">${ic('help')}<span class="hide-sm">Ayuda</span></a>
    <a class="btn ghost sm" href="#/settings">${ic('gear')}<span class="hide-sm">Configuración</span></a></header>`;
}
document.head.insertAdjacentHTML('beforeend', '<style>@media(max-width:560px){.hide-sm{display:none}}</style>');

function servicesBanner() {
  const s = G.status;
  if (!s) return '';
  if (!s.native) return `<div class="banner bad">${ic('alert')}<div><b>Estás fuera de la app de Android.</b><br><span class="small">Subir videos, analizarlos y exportarlos solo funciona dentro de la app instalada.</span></div></div>`;
  const miss = [];
  if (!s.transcription) miss.push('transcripción automática (subtítulos)');
  if (!s.llm) miss.push('selección inteligente con Claude');
  if (!miss.length) return '';
  return `<div class="banner">${ic('alert')}<div><b>Funciones de IA sin configurar:</b> ${miss.join(' y ')}.<br><span class="small">Podés usar Clipazos igual: los clips se eligen por energía de audio y no hay subtítulos automáticos. <a href="#/settings">Cargá tus claves en Configuración</a>.</span></div></div>`;
}

/* ------------------------------------------------------------------ */
/* Router                                                               */
/* ------------------------------------------------------------------ */

async function route() {
  if (G.cleanup) { try { G.cleanup(); } catch {} G.cleanup = null; }
  const h = location.hash.slice(1) || '/';
  const app = $('#app');
  window.scrollTo(0, 0);
  try {
    let m;
    if (h === '/') G.cleanup = await HomeView(app);
    else if ((m = /^\/p\/([A-Za-z0-9_-]+)\/c\/([A-Za-z0-9_-]+)$/.exec(h))) G.cleanup = await EditorView(app, m[1], m[2]);
    else if ((m = /^\/p\/([A-Za-z0-9_-]+)$/.exec(h))) G.cleanup = await ProjectView(app, m[1]);
    else if (h === '/settings') G.cleanup = await SettingsView(app);
    else if (h === '/help') G.cleanup = HelpView(app);
    else location.hash = '#/';
  } catch (e) {
    app.innerHTML = header() + `<div class="wrap"><div class="banner bad">${ic('alert')}<div>${esc(e.message)}<br><a href="#/">Volver al inicio</a></div></div></div>`;
  }
}
window.addEventListener('hashchange', route);

async function loadGlobals() {
  try { G.status = await api('/api/status'); G.settings = await api('/api/settings'); } catch (e) { G.status = null; }
}

/* ------------------------------------------------------------------ */
/* Inicio                                                               */
/* ------------------------------------------------------------------ */

async function startPick() {
  if (G.upload) return toast('Ya hay una copia en curso.', 'bad');
  if (!CZ.native.available) return toast('Esto solo funciona dentro de la app de Android.', 'bad');
  G.upload = { name: 'Video', size: 0, loaded: 0, t0: Date.now(), phase: 'wait' };
  renderUpload();
  try {
    const r = await CZ.native.pickVideo((a, b) => { Object.assign(G.upload, { loaded: a, size: b, phase: 'copy' }); renderUpload(); });
    if (r.canceled) { G.upload = null; renderUpload(); return; }
    if (r.error) throw new Error(r.error);
    G.upload = { ...G.upload, name: r.name, size: r.size, loaded: r.size, phase: 'process' }; renderUpload();
    const p = await CZ.api.createFromPick(r);
    G.upload = null; toast('Video listo', 'ok'); location.hash = `#/p/${p.id}`;
  } catch (e) { G.upload = null; renderUpload(); fail(e); }
}
function renderUpload() {
  const box = $('#uploadBox');
  if (!box) return;
  const u = G.upload;
  if (!u) { box.innerHTML = ''; return; }
  const pct = u.size ? (u.loaded / u.size) * 100 : 0;
  const sp = u.loaded / Math.max(1, (Date.now() - u.t0) / 1000);
  const eta = sp ? (u.size - u.loaded) / sp : 0;
  box.innerHTML = `<div class="card" style="margin-top:18px"><div class="body">
    <div class="row between"><div><b>${esc(u.name)}</b><div class="small muted">${u.size ? bytes(u.size) : ''}</div></div>
    <button class="btn danger sm" id="cancelUp">${ic('x')} Cancelar</button></div>
    <div class="bar" style="margin:14px 0 8px"><i style="width:${pct}%"></i></div>
    <div class="small muted">${u.phase === 'wait' ? 'Elegí un video en tu galería…' : u.phase === 'process' ? '<span class="spin"></span> Leyendo el video y creando la miniatura…' : `Copiando el video a la app ${pct.toFixed(0)}% · faltan ${fmt(eta)}`}</div></div></div>`;
  $('#cancelUp').onclick = () => { CZ.native.cancelPick(); if (u.phase === 'wait') { G.upload = null; renderUpload(); } };
}

function exportAct(b) {
  const a = b.dataset.act;
  if (a === 'open') { CZ.native.openUri(b.dataset.uri, b.dataset.mime || 'video/mp4'); return true; }
  if (a === 'share') { CZ.native.share(b.dataset.uri, b.dataset.mime || 'video/mp4'); return true; }
  return false;
}

async function HomeView(app) {
  await loadGlobals();
  app.innerHTML = header() + `
  <div class="wrap">
    <section class="hero" id="drop">
      <h1>Convertí videos largos en clips virales</h1>
      <p>Elegí un video de tu galería, decidí cuántos clips querés y la IA busca los mejores momentos, los subtitula y los deja listos para TikTok, Shorts y Reels. Todo se hace en tu teléfono.</p>
      <button class="upload-btn" id="pickBtn">${ic('upload')} Subir un video</button>
    </section>
    <div id="uploadBox"></div>
    ${servicesBanner()}
    <section class="section"><h2>${ic('film')} Proyectos recientes</h2><div id="projects" class="grid"></div></section>
    <section class="section"><h2>${ic('check')} Videos procesados</h2><div id="exports" class="grid"></div></section>
  </div>`;
  $('#pickBtn').onclick = startPick;
  renderUpload();

  let alive = true, timer;
  const load = async () => {
    try {
      const [ps, ex] = await Promise.all([api('/api/projects'), api('/api/exports')]);
      if (!alive) return;
      $('#projects').innerHTML = ps.length ? ps.map(projectCard).join('') : `<div class="empty" style="grid-column:1/-1">Todavía no hay proyectos. Subí tu primer video para empezar.</div>`;
      $('#exports').innerHTML = ex.length ? ex.map(exportCard).join('') : `<div class="empty" style="grid-column:1/-1">Cuando exportes clips, aparecerán acá y también en tu galería (carpeta Películas/Clipazos).</div>`;
      if (ps.some((p) => p.status === 'analyzing' || p.status === 'downloading')) timer = setTimeout(load, 2000);
    } catch (e) { fail(e); }
  };
  load();
  app.onclick = async (e) => {
    const b = e.target.closest('[data-act]');
    if (!b) return;
    const id = b.dataset.id;
    e.preventDefault();
    if (exportAct(b)) return;
    if (b.dataset.act === 'rename') { const n = await promptBox('Renombrar proyecto', b.dataset.name); if (n) { await api(`/api/projects/${id}`, { method: 'PATCH', json: { name: n } }).catch(fail); load(); } }
    if (b.dataset.act === 'delete') { if (await confirmBox('¿Eliminar proyecto?', 'Se borrarán el video copiado, los clips y los ajustes de este proyecto. Los videos ya exportados quedan en tu galería.')) { await api(`/api/projects/${id}`, { method: 'DELETE' }).catch(fail); load(); } }
    if (b.dataset.act === 'delexp') { if (await confirmBox('¿Eliminar este video exportado?', 'Se borra el archivo MP4 de tu galería.')) { await api(`/api/projects/${b.dataset.pid}/exports/${id}`, { method: 'DELETE' }).catch(fail); load(); } }
  };
  return () => { alive = false; clearTimeout(timer); app.onclick = null; };
}

const STATUS = { uploaded: ['Listo para analizar', ''], analyzing: ['Analizando…', 'violet'], ready: ['Clips listos', 'ok'], downloading: ['Descargando…', 'violet'], error: ['Con error', 'bad'] };
function projectCard(p) {
  const [label, cls] = STATUS[p.status] || ['', ''];
  return `<article class="card hover"><a href="#/p/${p.id}" class="thumb" style="background-image:url(${p.thumbUrl})" aria-label="Abrir ${esc(p.name)}"><span class="dur">${fmt(p.duration)}</span></a>
  <div class="body"><h3 title="${esc(p.name)}">${esc(p.name)}</h3>
  <div class="row"><span class="chip ${cls}">${label}</span>${p.clipCount ? `<span class="chip">${p.clipCount} ${p.clipCount === 1 ? 'clip' : 'clips'}</span>` : ''}<span class="small muted">${ago(p.updatedAt)}</span></div>
  <div class="row" style="margin-top:12px"><a class="btn sm primary" href="#/p/${p.id}">Abrir</a><button class="btn sm ghost icon" data-act="rename" data-id="${p.id}" data-name="${esc(p.name)}" title="Renombrar" aria-label="Renombrar">${ic('edit')}</button><button class="btn sm ghost icon danger" data-act="delete" data-id="${p.id}" title="Eliminar" aria-label="Eliminar">${ic('trash')}</button></div></div></article>`;
}
function exportCard(x) {
  const data = `data-uri="${esc(x.uri)}" data-mime="${esc(x.mime || 'video/mp4')}"`;
  return `<article class="card"><div class="thumb" style="background-image:url(${x.thumbUrl})"><span class="dur">${fmt(x.duration)}</span></div>
  <div class="body"><h3 title="${esc(x.clipTitle)}">${esc(x.clipTitle)}</h3><div class="small muted">${esc(x.projectName || '')}</div>
  <div class="row" style="margin:8px 0"><span class="chip">${esc(x.aspect)}</span><span class="chip">${x.quality}p</span><span class="chip">${bytes(x.size)}</span></div>
  <div class="row"><button class="btn sm primary" data-act="open" ${data}>${ic('play')} Abrir</button><button class="btn sm" data-act="share" ${data}>${ic('share')} Compartir</button><button class="btn sm ghost icon danger" data-act="delexp" data-pid="${x.projectId}" data-id="${x.id}" aria-label="Eliminar">${ic('trash')}</button></div></div></article>`;
}

/* ------------------------------------------------------------------ */
/* Proyecto                                                             */
/* ------------------------------------------------------------------ */

const CATEGORY = { divertido: 'Divertido', 'reacción': 'Reacción', frase: 'Frase', emocionante: 'Emocionante', 'discusión': 'Discusión', inesperado: 'Inesperado', informativo: 'Informativo', historia: 'Historia', destacado: 'Destacado', manual: 'Manual' };
const ENGINE = { claude: ['IA · Claude', 'violet'], heuristic: ['Análisis de audio y texto', ''], audio: ['Solo audio', 'warn'], manual: ['Manual', ''] };
const scoreColor = (s) => (s >= 80 ? '#2dd4bf' : s >= 60 ? '#2f6bff' : '#8b5cf6');

async function ProjectView(app, pid) {
  await loadGlobals();
  let P = await api(`/api/projects/${pid}`);
  let alive = true, timer, sort = 'score', cfgOpen = false;
  const cfg = { count: P.settings?.count || 5, custom: ![3, 5, 10, 15].includes(P.settings?.count || 5), dur: 'auto' };
  if (P.settings) {
    const { minDur, maxDur } = P.settings;
    cfg.dur = minDur === 30 && maxDur === 45 ? 's' : minDur === 45 && maxDur === 60 ? 'm' : minDur === 60 && maxDur === 80 ? 'l' : 'auto';
  }
  const DURS = { s: [30, 45, '30–45 s'], m: [45, 60, '45–60 s'], l: [60, 80, '60–80 s'], auto: [30, 80, 'Automático (30–80 s)'] };
  let jobs = []; // exportaciones en lote

  const render = () => {
    if (!alive) return;
    app.innerHTML = header(`<a class="btn ghost sm" href="#/">${ic('back')} Inicio</a>`) + `<div class="wrap">${body()}</div>`;
    wire();
  };

  const summary = () => `<div class="card"><div class="row" style="padding:14px;gap:16px;align-items:flex-start"><div class="thumb" style="background-image:url(${P.thumbUrl});width:160px;border-radius:12px;flex:none"><span class="dur">${fmt(P.source.duration || 0)}</span></div>
    <div style="flex:1;min-width:200px"><div class="row between"><h2 id="pname" style="cursor:pointer" title="Tocá para renombrar">${esc(P.name)} ${ic('edit')}</h2><button class="btn ghost sm danger" id="delP">${ic('trash')} Eliminar</button></div>
    ${P.source.width ? `<div class="row" style="margin-top:8px"><span class="chip">${P.source.width}×${P.source.height}</span><span class="chip">${bytes(P.source.size)}</span>${P.source.hasAudio ? '' : '<span class="chip bad">Sin audio</span>'}</div>` : ''}</div></div></div>`;

  const body = () => {
    let h = summary();
    if (P.status === 'downloading') {
      const d = P.download || {};
      return h + `<div class="card" style="margin-top:20px"><div class="body"><h3>${ic('download')} Descargando el video…</h3><div class="bar" style="margin:14px 0"><i style="width:${(d.progress || 0) * 100}%"></i></div><div class="small muted">${esc(d.message || '')}</div></div></div>`;
    }
    if (P.status === 'error') return h + `<div class="banner bad">${ic('alert')}<div>${esc(P.analysis?.error || 'Ocurrió un error con este proyecto.')}</div></div>`;
    if (P.status === 'analyzing') return h + analyzingPanel();
    if (P.status === 'uploaded' || cfgOpen) h += configPanel();
    if (P.status === 'ready') h += resultsPanel();
    return h;
  };

  const configPanel = () => {
    const s = G.status || {};
    const customVal = cfg.custom ? cfg.count : '';
    const err = P.analysis?.stage === 'error' ? `<div class="banner bad">${ic('alert')}<div><b>Falló el análisis anterior:</b> ${esc(P.analysis.error)}</div></div>` : '';
    return `${err}${servicesBanner()}<section class="section card"><div class="body" style="display:grid;gap:20px">
      <h2>${ic('spark')} ¿Cómo querés tus clips?</h2>
      <div><div class="small muted" style="margin-bottom:8px;font-weight:600">1 · ¿Cuántos clips querés?</div><div class="chips" id="cnt">
        ${[3, 5, 10, 15].map((n) => `<button class="opt ${!cfg.custom && cfg.count === n ? 'on' : ''}" data-n="${n}">${n} clips</button>`).join('')}
        <button class="opt ${cfg.custom ? 'on' : ''}" data-n="custom">Personalizado</button>${cfg.custom ? `<input type="number" id="customN" min="1" max="40" value="${customVal}" style="width:90px">` : ''}</div></div>
      <div><div class="small muted" style="margin-bottom:8px;font-weight:600">2 · ¿Cuánto tienen que durar?</div><div class="chips" id="dur">${Object.entries(DURS).map(([k, v]) => `<button class="opt ${cfg.dur === k ? 'on' : ''}" data-d="${k}">${v[2]}</button>`).join('')}</div></div>
      <div class="row between"><div class="hint" style="max-width:560px">${s.llm ? 'Claude elige los momentos según lo que se dice.' : 'Sin clave de Claude: se usa una selección por audio y texto.'} ${s.transcription ? 'Los subtítulos se generan automáticamente.' : 'Sin transcripción: no habrá subtítulos automáticos.'}</div>
      <div class="row">${P.status === 'ready' ? '<button class="btn ghost" id="cfgClose">Cancelar</button>' : ''}<button class="btn primary" id="analyze" style="padding:14px 28px;font-size:1.05rem">${ic('spark')} Analizar con IA</button></div></div>
      ${P.status === 'ready' ? `<div class="hint">Al volver a analizar se reemplazan los clips generados (los manuales se conservan).</div>` : ''}
    </div></section>`;
  };

  const STEPS = [['audio', 'Extrayendo el audio y midiendo su energía'], ['transcribe', 'Transcribiendo lo que se dice'], ['select', 'Eligiendo los mejores momentos'], ['finish', 'Preparando clips y subtítulos']];
  const analyzingPanel = () => {
    const a = P.analysis || {};
    const idx = Math.max(0, STEPS.findIndex((s) => s[0] === a.stage));
    const overall = ((idx + (a.progress || 0)) / STEPS.length) * 100;
    return `<section class="section card"><div class="body">
      <h2>${ic('spark')} La IA está trabajando en tu video</h2>
      <p class="muted">${esc(a.message || '')}</p>
      <div class="bar" style="margin:16px 0"><i style="width:${Math.max(3, overall)}%"></i></div>
      <div class="steps">${STEPS.map((s, i) => `<div class="step ${i < idx ? 'done' : i === idx ? 'active' : ''}"><span class="dot">${i < idx ? ic('check') : i + 1}</span><div style="flex:1">${s[1]}</div>${i === idx ? `<span class="small muted">${Math.round((a.progress || 0) * 100)}%</span>` : ''}</div>`).join('')}</div>
      <div class="row between"><span class="small muted">Dejá la app abierta y la pantalla encendida mientras se analiza. Tiempo: ${fmt((Date.now() - (a.startedAt || Date.now())) / 1000)}</span><button class="btn danger sm" id="cancelA">${ic('x')} Cancelar</button></div></div></section>`;
  };

  const sorted = () => {
    const c = [...P.clips];
    if (sort === 'score') c.sort((a, b) => (b.score ?? -1) - (a.score ?? -1));
    if (sort === 'time') c.sort((a, b) => a.start - b.start);
    if (sort === 'dur') c.sort((a, b) => (b.end - b.start) - (a.end - a.start));
    return c;
  };

  const resultsPanel = () => {
    const a = P.analysis || {};
    const warns = (a.warnings || []).map((w) => `<div class="banner">${ic('alert')}<div class="small">${esc(w)}</div></div>`).join('');
    const exports = P.exports.length ? `<section class="section"><h2>${ic('check')} Exportaciones de este proyecto</h2><div class="grid">${P.exports.map((x) => exportCard({ ...x, projectId: P.id, projectName: P.name, thumbUrl: P.thumbUrl })).join('')}</div></section>` : '';
    return `${warns}<section class="section"><div class="row between" style="margin-bottom:14px"><h2>${ic('film')} ${P.clips.length} ${P.clips.length === 1 ? 'clip' : 'clips'}</h2>
      <div class="row"><select id="sort" style="width:auto"><option value="score" ${sort === 'score' ? 'selected' : ''}>Ordenar: mayor puntuación</option><option value="time" ${sort === 'time' ? 'selected' : ''}>Ordenar: orden en el video</option><option value="dur" ${sort === 'dur' ? 'selected' : ''}>Ordenar: duración</option></select>
      <button class="btn sm" id="addManual">${ic('plus')} Clip manual</button><button class="btn sm" id="reanalyze">${ic('refresh')} Volver a analizar</button><button class="btn sm primary" id="expAll">${ic('download')} Exportar todos</button></div></div>
      <div class="hint" style="margin:-6px 0 14px">La puntuación (1–99) es una <b>estimación del potencial de interacción</b>, no una garantía de que el clip se vuelva viral.</div>
      <div id="batch"></div>
      <div class="clips">${sorted().map(clipCard).join('') || '<div class="empty">No se generaron clips.</div>'}</div></section>${exports}`;
  };

  const clipCard = (c) => {
    const d = c.end - c.start;
    const [el, ecls] = ENGINE[c.engine] || ['', ''];
    const sc = c.score;
    return `<article class="card clip hover" data-id="${c.id}"><div class="pv"><img src="${c.thumbUrl}" alt="">
      ${sc != null ? `<div class="score" style="--c:${scoreColor(sc)};--p:${sc}"><span>${sc}</span></div>` : ''}<span class="thumb" style="all:unset"></span></div>
      <div class="body"><h3>${esc(c.title)}</h3><div class="small muted" style="min-height:2.6em">${esc(c.description) || '&nbsp;'}</div>
      <div class="row" style="margin:10px 0"><span class="chip">${Math.round(d)} s</span><span class="chip">${fmt(c.start)} → ${fmt(c.end)}</span><span class="chip ${ecls}">${esc(el)}</span>${c.category && c.category !== 'manual' ? `<span class="chip">${esc(CATEGORY[c.category] || c.category)}</span>` : ''}</div>
      <div class="small muted">Del video original: ${fmt(c.start)} – ${fmt(c.end)}</div>
      <div class="acts"><a class="btn sm primary" href="#/p/${P.id}/c/${c.id}">${ic('scissors')} Editar</a><button class="btn sm icon" data-a="dup" data-id="${c.id}" title="Duplicar" aria-label="Duplicar">${ic('copy')}</button><button class="btn sm icon danger" data-a="del" data-id="${c.id}" title="Eliminar" aria-label="Eliminar">${ic('trash')}</button></div></div></article>`;
  };

  const wire = () => {
    $('#pname')?.addEventListener('click', async () => { const n = await promptBox('Renombrar proyecto', P.name); if (n) { P = await api(`/api/projects/${pid}`, { method: 'PATCH', json: { name: n } }).catch(fail) || P; render(); } });
    $('#delP')?.addEventListener('click', async () => { if (await confirmBox('¿Eliminar proyecto?', 'Se borrarán el video, los clips y las exportaciones. No se puede deshacer.')) { await api(`/api/projects/${pid}`, { method: 'DELETE' }).catch(fail); location.hash = '#/'; } });
    $('#cnt')?.addEventListener('click', (e) => { const b = e.target.closest('[data-n]'); if (!b) return; if (b.dataset.n === 'custom') { cfg.custom = true; cfg.count = cfg.count || 7; } else { cfg.custom = false; cfg.count = Number(b.dataset.n); } render(); });
    $('#customN')?.addEventListener('input', (e) => { cfg.count = clamp(Math.round(Number(e.target.value) || 1), 1, 40); });
    $('#dur')?.addEventListener('click', (e) => { const b = e.target.closest('[data-d]'); if (b) { cfg.dur = b.dataset.d; render(); } });
    $('#analyze')?.addEventListener('click', async () => {
      const [minDur, maxDur] = DURS[cfg.dur];
      try { await api(`/api/projects/${pid}/analyze`, { json: { count: cfg.count, minDur, maxDur, language: G.settings.language } }); cfgOpen = false; P = await api(`/api/projects/${pid}`); render(); poll(); } catch (e) { fail(e); }
    });
    $('#cfgClose')?.addEventListener('click', () => { cfgOpen = false; render(); });
    $('#reanalyze')?.addEventListener('click', () => { cfgOpen = true; render(); $('#analyze')?.scrollIntoView({ behavior: 'smooth', block: 'center' }); });
    $('#cancelA')?.addEventListener('click', () => api(`/api/projects/${pid}/cancel`, { json: {} }).catch(fail));
    $('#sort')?.addEventListener('change', (e) => { sort = e.target.value; render(); });
    $('#addManual')?.addEventListener('click', async () => {
      try { const c = await api(`/api/projects/${pid}/clips`, { json: { start: 0, end: Math.min(45, P.source.duration), title: 'Clip manual' } }); location.hash = `#/p/${pid}/c/${c.id}`; } catch (e) { fail(e); }
    });
    $('#expAll')?.addEventListener('click', exportAll);
    app.onclick = async (e) => {
      const b = e.target.closest('[data-a],[data-act]');
      if (!b) return;
      if (exportAct(b)) return;
      if (b.dataset.a === 'dup') { await api(`/api/projects/${pid}/clips/${b.dataset.id}/duplicate`, { json: {} }).catch(fail); P = await api(`/api/projects/${pid}`); toast('Clip duplicado', 'ok'); render(); }
      if (b.dataset.a === 'del') { if (await confirmBox('¿Eliminar este clip?', 'Se pierde su edición (el video original no se toca).')) { await api(`/api/projects/${pid}/clips/${b.dataset.id}`, { method: 'DELETE' }).catch(fail); P = await api(`/api/projects/${pid}`); render(); } }
      if (b.dataset.act === 'delexp') { if (await confirmBox('¿Eliminar este video exportado?', 'Se borra el archivo MP4 de tu galería.')) { await api(`/api/projects/${pid}/exports/${b.dataset.id}`, { method: 'DELETE' }).catch(fail); P = await api(`/api/projects/${pid}`); render(); } }
    };
  };

  async function exportAll() {
    try {
      jobs = await api(`/api/projects/${pid}/export-all`, { json: {} });
      renderBatch();
      const tick = async () => {
        if (!alive) return;
        jobs = await api('/api/jobs/query', { json: { ids: jobs.map((j) => j.id) } }).catch(() => jobs);
        renderBatch();
        if (jobs.some((j) => ['queued', 'running'].includes(j.status))) setTimeout(tick, 800);
        else { P = await api(`/api/projects/${pid}`); render(); renderBatch(); }
      };
      tick();
    } catch (e) { fail(e); }
  }
  function renderBatch() {
    const el = $('#batch');
    if (!el || !jobs.length) return;
    const done = jobs.filter((j) => j.status === 'done').length;
    const active = jobs.some((j) => ['queued', 'running'].includes(j.status));
    el.innerHTML = `<div class="card" style="margin-bottom:16px"><div class="body"><div class="row between"><b>${active ? '<span class="spin"></span> ' : ''}Exportando ${done}/${jobs.length}</b>${!active && done ? `<span class="chip ok">Guardados en Películas/Clipazos</span>` : ''}</div>
      ${active ? '<div class="hint" style="margin-top:8px">La exportación se hace en tiempo real en tu teléfono: dejá la app abierta y la pantalla encendida.</div>' : ''}
      <div class="bar" style="margin-top:10px"><i style="width:${(jobs.reduce((a, j) => a + (j.status === 'done' ? 1 : j.progress || 0), 0) / jobs.length) * 100}%"></i></div>
      ${jobs.filter((j) => j.status === 'error').map((j) => `<div class="small" style="color:var(--bad);margin-top:6px">${esc(P.clips.find((c) => c.id === j.cid)?.title || 'Clip')}: ${esc(j.error)}</div>`).join('')}</div></div>`;
  }

  async function poll() {
    clearTimeout(timer);
    if (!alive) return;
    try {
      const n = await api(`/api/projects/${pid}`);
      const changed = n.status !== P.status;
      P = n;
      if (n.status === 'analyzing' || n.status === 'downloading') {
        // actualización liviana sin perder foco
        if (changed || !$('.steps')) render(); else { const keepBatch = null; render(); }
        timer = setTimeout(poll, 900);
      } else if (changed) render();
    } catch (e) { timer = setTimeout(poll, 3000); }
  }
  render();
  if (P.status === 'analyzing' || P.status === 'downloading') poll();
  return () => { alive = false; clearTimeout(timer); app.onclick = null; };
}

/* ------------------------------------------------------------------ */
/* Configuración y ayuda                                                */
/* ------------------------------------------------------------------ */

async function SettingsView(app) {
  await loadGlobals();
  const s = G.status || {};
  const cfg = await api('/api/settings');
  const row = (ok, title, detail) => `<div class="status-line"><span class="chip ${ok ? 'ok' : 'warn'}">${ok ? 'Activo' : 'Falta'}</span><div><b>${title}</b><div class="small muted">${detail}</div></div></div>`;
  const langs = [['auto', 'Detectar automáticamente'], ['es', 'Español'], ['en', 'Inglés'], ['pt', 'Portugués'], ['fr', 'Francés'], ['it', 'Italiano'], ['de', 'Alemán']];
  app.innerHTML = header(`<a class="btn ghost sm" href="#/">${ic('back')} Inicio</a>`) + `<div class="wrap" style="max-width:820px">
    <h1 style="margin-bottom:18px">Configuración</h1>
    <section class="card"><div class="body" style="display:grid;gap:14px"><h2>Idioma</h2>
      <label class="f">Idioma de la interfaz<select disabled><option>Español</option></select></label>
      <label class="f">Idioma de lo que se habla en tus videos (transcripción)<select id="lang">${langs.map(([v, n]) => `<option value="${v}" ${cfg.language === v ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <div class="hint">Si siempre hablás el mismo idioma, elegirlo mejora la precisión de los subtítulos.</div></div></section>
    <section class="card" style="margin-top:18px"><div class="body" style="display:grid;gap:14px"><h2>${ic('spark')} Claves de IA</h2>
      <p class="muted small" style="margin:0">Clipazos corre en tu teléfono, pero la transcripción y la elección inteligente de clips usan servicios de IA en internet. Cargá tus propias claves: se guardan <b>solo en este teléfono</b>.</p>
      <h3 style="color:var(--sky)">Transcripción (subtítulos)</h3>
      <label class="f">Clave (API key)<input type="password" id="tKey" value="${esc(cfg.transcribe.key)}" autocomplete="off" placeholder="sk-… o gsk_…"></label>
      <div class="fields"><label class="f">Dirección del servicio<input type="text" id="tUrl" value="${esc(cfg.transcribe.baseUrl)}"></label><label class="f">Modelo<input type="text" id="tModel" value="${esc(cfg.transcribe.model)}"></label></div>
      <div class="row"><button class="btn sm" id="useOpenAI">Usar OpenAI</button><button class="btn sm" id="useGroq">Usar Groq (tiene plan gratuito)</button></div>
      <h3 style="color:var(--sky)">Elección de clips (Claude)</h3>
      <label class="f">Clave de Anthropic<input type="password" id="lKey" value="${esc(cfg.llm.key)}" autocomplete="off" placeholder="sk-ant-…"></label>
      <label class="f">Modelo<input type="text" id="lModel" value="${esc(cfg.llm.model)}"></label>
      <div class="row"><button class="btn primary" id="saveKeys">Guardar</button></div>
      <div class="hint">Al analizar, el audio del video (en trozos de 10 min) se envía al servicio de transcripción y el texto transcripto a Claude. Usá solo videos que podés compartir con esos servicios.</div></div></section>
    <section class="card" style="margin-top:18px"><div class="body" style="display:grid;gap:12px"><h2>Estado</h2>
      ${row(!!s.native, 'App de Android', s.native ? 'Todo se procesa en este teléfono.' : 'Estás viendo esto fuera de la app: no se puede procesar video.')}
      ${row(!!s.transcription, 'Transcripción automática (subtítulos)', s.transcription ? `Conectada (${esc(s.transcriptionModel)}).` : 'Sin clave. No habrá subtítulos automáticos.')}
      ${row(s.llm, 'Selección inteligente de clips (Claude)', s.llm ? `Conectada (${esc(s.llmModel)}).` : 'Sin clave. Los clips se eligen con una heurística de audio y texto.')}
      <div class="hint">Importar desde un enlace de YouTube no está disponible en la versión de Android (necesita un programa que no puede correr en el teléfono): descargá el video y subilo desde tu galería.</div></div></section></div>`;
  $('#lang').onchange = async (e) => { await api('/api/settings', { method: 'PUT', json: { language: e.target.value } }).catch(fail); toast('Idioma guardado', 'ok'); };
  $('#useOpenAI').onclick = () => { $('#tUrl').value = 'https://api.openai.com/v1'; $('#tModel').value = 'whisper-1'; };
  $('#useGroq').onclick = () => { $('#tUrl').value = 'https://api.groq.com/openai/v1'; $('#tModel').value = 'whisper-large-v3-turbo'; };
  $('#saveKeys').onclick = async () => {
    try {
      await api('/api/settings', { method: 'PUT', json: { transcribe: { key: $('#tKey').value, baseUrl: $('#tUrl').value, model: $('#tModel').value }, llm: { key: $('#lKey').value, model: $('#lModel').value } } });
      toast('Claves guardadas', 'ok'); route();
    } catch (e) { fail(e); }
  };
  return () => {};
}

function HelpView(app) {
  app.innerHTML = header(`<a class="btn ghost sm" href="#/">${ic('back')} Inicio</a>`) + `<div class="wrap help" style="max-width:820px"><h1 style="margin-bottom:6px">Tutorial</h1><p class="muted">De un video largo a clips listos para publicar, todo en tu teléfono.</p>
    <ol>
      <li><b>Cargá tus claves de IA</b> en Configuración (una vez). Sin ellas la app funciona, pero sin subtítulos y con una selección de clips más simple.</li>
      <li><b>Subí tu video.</b> Tocá “Subir un video” y elegilo de tu galería. Se copia a la app (necesitás espacio libre similar al tamaño del video).</li>
      <li><b>Elegí cuántos clips querés</b> (3, 5, 10, 15 o la cantidad que quieras) y <b>cuánto deben durar</b> (30 s a 1:20).</li>
      <li><b>Tocá “Analizar con IA”.</b> Vas a ver paso a paso qué hace: extrae el audio, transcribe y busca los mejores momentos. Dejá la app abierta.</li>
      <li><b>Mirá los resultados.</b> Cada clip trae título, descripción, duración, el momento original y una puntuación. Podés ordenarlos.</li>
      <li><b>Abrí los que te gusten</b> con “Editar”: recortá, cambiá el encuadre, los subtítulos, estilos, efectos, stickers y música.</li>
      <li><b>Exportá.</b> El video se guarda en tu galería (Películas/Clipazos), en MP4, sin marca de agua.</li></ol>
    <h2 style="margin:26px 0 12px">Preguntas frecuentes</h2>
    <details><summary>¿Cuánto tarda exportar?</summary><p class="muted">La exportación se graba en tiempo real: un clip de 45 s tarda unos 45 s (la mitad si lo acelerás a 2×). Dejá la pantalla encendida y no cambies de app mientras exporta.</p></details>
    <details><summary>¿Qué significa la puntuación?</summary><p class="muted">Es una estimación del potencial de interacción que hace la IA según el contenido y el audio. No garantiza que el clip se vuelva viral.</p></details>
    <details><summary>¿Lo que veo en el editor es lo que se exporta?</summary><p class="muted">Sí: la vista del editor y la exportación usan el mismo motor de dibujo. La música y los efectos de sonido solo se escuchan en el video exportado.</p></details>
    <details><summary>¿Por qué no tengo subtítulos automáticos?</summary><p class="muted">Necesitan un servicio de voz a texto. Cargá la clave en <a href="#/settings">Configuración</a>.</p></details>
    <details><summary>¿Se guardan mis cambios?</summary><p class="muted">Sí, automáticamente en el teléfono. Podés volver a editar cualquier proyecto desde el inicio.</p></details>
    <details><summary>¿Seguimiento del hablante y reencuadre automático?</summary><p class="muted">Todavía no están disponibles (necesitan detección de rostros). Podés encuadrar a mano arrastrando el video, con zoom, o con un paneo animado.</p></details>
    <details><summary>¿Calidad 4K?</summary><p class="muted">No: en el teléfono se exporta hasta 1080p, para que sea estable.</p></details></div>`;
  return () => {};
}

/* ------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', route);
window.__clipazos = { $, $$, esc, clamp, fmt, fmtMs, parseT, bytes, ic, api, toast, fail, modal, confirmBox, promptBox, header, G, ENGINE, CATEGORY };
