'use strict';
/* Compositor de video en canvas. Lo usan la vista en vivo del editor y la exportación,
   así que lo que se ve en pantalla es exactamente lo que se exporta. */
(() => {
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const num = (v, d) => (Number.isFinite(Number(v)) && v !== null && v !== '' ? Number(v) : d);
const evenRound = (n) => Math.max(2, Math.round(n / 2) * 2);

const CSS_FILTER = { none: 'none', vivid: 'saturate(1.3) contrast(1.08)', cine: 'contrast(1.12) saturate(.9) sepia(.12) brightness(.95)', gaming: 'saturate(1.45) contrast(1.12)', bw: 'grayscale(1) contrast(1.1)', warm: 'sepia(.25) saturate(1.1)', cold: 'hue-rotate(12deg) saturate(1.05)', sharp: 'contrast(1.06)' };
const FONTS = ['Poppins', 'Inter', 'Inter Black', 'DejaVu Sans', 'DejaVu Serif'];

function outSize(aspect, quality) {
  const q = clamp(num(quality, 1080), 240, 2160);
  if (aspect === '16:9') return [evenRound((q * 16) / 9), evenRound(q)];
  if (aspect === '1:1') return [evenRound(q), evenRound(q)];
  return [evenRound(q), evenRound((q * 16) / 9)];
}

let fontsReady = null;
function loadFonts() {
  if (!fontsReady) fontsReady = Promise.all(FONTS.flatMap((f) => [`700 40px "${f}"`, `400 40px "${f}"`, `italic 700 40px "${f}"`].map((d) => document.fonts.load(d).catch(() => null)))).then(() => true);
  return fontsReady;
}

const hexA = (hex, a) => { const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); const h = m ? m[1] : '000000'; return `rgba(${parseInt(h.slice(0, 2), 16)},${parseInt(h.slice(2, 4), 16)},${parseInt(h.slice(4, 6), 16)},${a})`; };

/* ---------- subtítulos ---------- */
function currentCaption(captions, t, perLine) {
  const per = Math.max(1, Math.round(perLine || 3));
  for (const c of captions || []) {
    if (!c.words?.length) continue;
    if (t < c.words[0].s - 0.05 || t > c.words[c.words.length - 1].e + 0.3) continue;
    const chunks = []; let cur = [];
    for (const w of c.words) {
      if (cur.length && (cur.length >= per || w.s - cur[cur.length - 1].e > 0.8)) { chunks.push(cur); cur = []; }
      cur.push(w);
      if (/[.!?…]$/.test(w.w) && cur.length >= 2) { chunks.push(cur); cur = []; }
    }
    if (cur.length) chunks.push(cur);
    for (let i = 0; i < chunks.length; i++) {
      const ch = chunks[i], nx = chunks[i + 1];
      const end = nx ? nx[0].s : ch[ch.length - 1].e + 0.15;
      if (t >= ch[0].s - 0.02 && t < end) { let wi = 0; ch.forEach((w, k) => { if (t >= w.s) wi = k; }); return { words: ch, wi, key: `${c.id}:${i}` }; }
    }
  }
  return null;
}

function drawSubs(g, W, H, s, captions, t) {
  if (!s || !s.on) return;
  const cc = currentCaption(captions, t, s.wordsPerLine);
  if (!cc) return;
  const fpx = (s.size / 100) * H;
  g.font = `${s.italic ? 'italic ' : ''}${s.bold === false ? 400 : 700} ${fpx}px "${s.font}", sans-serif`;
  g.textBaseline = 'alphabetic'; g.textAlign = 'left';
  const words = cc.words.map((w) => (s.uppercase ? String(w.w).toUpperCase() : String(w.w)));
  const space = g.measureText(' ').width;
  const widths = words.map((w) => g.measureText(w).width);
  const maxW = W * 0.88;
  const lines = []; let cur = { idx: [], w: 0 };
  words.forEach((_, i) => {
    const add = (cur.idx.length ? space : 0) + widths[i];
    if (cur.idx.length && cur.w + add > maxW) { lines.push(cur); cur = { idx: [i], w: widths[i] }; } else { cur.idx.push(i); cur.w += add; }
  });
  if (cur.idx.length) lines.push(cur);
  const lh = fpx * 1.18, total = lines.length * lh, marginV = (s.marginV / 100) * H;
  const top = s.pos === 'top' ? marginV : s.pos === 'middle' ? (H - total) / 2 : H - marginV - total;
  const age = t - cc.words[0].s;
  g.save();
  let scale = 1;
  if (s.anim === 'pop') scale = 0.85 + 0.15 * clamp(age / 0.14, 0, 1);
  if (s.anim === 'fade') g.globalAlpha = clamp(age / 0.14, 0, 1);
  const cx = W / 2, cy = top + total / 2;
  g.translate(cx, cy); g.scale(scale, scale); g.translate(-cx, -cy);
  g.lineJoin = 'round'; g.miterLimit = 2;
  const outlineW = ((fpx * (s.outlineW || 0)) / 100) * 2;
  const sh = ((s.shadow || 0) * H) / 1080;
  lines.forEach((ln, li) => {
    const y = top + li * lh + fpx * 0.92;
    let x = (W - ln.w) / 2;
    if (s.box) {
      g.fillStyle = hexA(s.boxColor || '#000000', 0.6);
      const bx = x - fpx * 0.4, bw = ln.w + fpx * 0.8, by = top + li * lh + fpx * 0.02, bh = lh * 0.98, r = fpx * 0.2;
      g.beginPath(); g.moveTo(bx + r, by); g.arcTo(bx + bw, by, bx + bw, by + bh, r); g.arcTo(bx + bw, by + bh, bx, by + bh, r); g.arcTo(bx, by + bh, bx, by, r); g.arcTo(bx, by, bx + bw, by, r); g.closePath(); g.fill();
    }
    ln.idx.forEach((i) => {
      const hl = s.highlightWords !== false && i === cc.wi;
      g.save();
      if (hl && s.anim === 'wordpop') { const wx = x + widths[i] / 2, wy = y - fpx * 0.3; g.translate(wx, wy); g.scale(1.12, 1.12); g.translate(-wx, -wy); }
      const hasOutline = !s.box && outlineW > 0;
      if (hasOutline) {
        g.strokeStyle = s.outline; g.lineWidth = outlineW;
        if (sh) { g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowOffsetX = sh; g.shadowOffsetY = sh; }
        g.strokeText(words[i], x, y);
        g.shadowColor = 'transparent';
      } else if (sh && !s.box) { g.shadowColor = 'rgba(0,0,0,.6)'; g.shadowOffsetX = sh; g.shadowOffsetY = sh; }
      g.fillStyle = hl ? s.highlight : s.color;
      g.fillText(words[i], x, y);
      g.restore();
      x += widths[i] + space;
    });
  });
  g.restore();
}

/* ---------- capas de video ---------- */
const scratch = document.createElement('canvas');
function dims(el) { return el.videoWidth ? [el.videoWidth, el.videoHeight] : el.naturalWidth ? [el.naturalWidth, el.naturalHeight] : [0, 0]; }
function drawCover(g, el, x, y, w, h) {
  const [ew, eh] = dims(el); if (!ew) return;
  const s = Math.max(w / ew, h / eh), vw = ew * s, vh = eh * s;
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.drawImage(el, x + (w - vw) / 2, y + (h - vh) / 2, vw, vh); g.restore();
}
function drawFill(g, el, sw, sh, x0, y0, W, H, e, p) {
  const z0 = e.zoom, z1 = e.zoomMode === 'dynamic' ? e.zoomEnd : e.zoom;
  const z = z0 + (z1 - z0) * p;
  const s = Math.max(W / sw, H / sh) * z, vw = sw * s, vh = sh * s;
  const px = e.panX2 != null ? e.panX + (e.panX2 - e.panX) * p : e.panX;
  g.save(); g.beginPath(); g.rect(x0, y0, W, H); g.clip();
  g.drawImage(el, x0 - (vw - W) * px, y0 - (vh - H) * e.panY, vw, vh);
  g.restore();
}

function overlayRect(ov, W, H, ew, eh) {
  const w = (ov.w / 100) * W, h = ew ? (w * eh) / ew : w;
  return { x: (ov.x / 100) * W - w / 2, y: (ov.y / 100) * H - h / 2, w, h };
}

/**
 * st: { video, sw, sh, e (edición), start, end, t (tiempo del video original), media(id) -> {el, kind} | null, showSel }
 */
function drawFrame(g, W, H, st) {
  const e = st.e, speed = clamp(num(e.speed, 1), 0.5, 2);
  const span = Math.max(0.1, st.end - st.start);
  const p = clamp((st.t - st.start) / span, 0, 1);
  const D = span / speed, tClip = clamp((st.t - st.start) / speed, 0, D);
  g.save();
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  const f = CSS_FILTER[e.filter] || 'none';
  const vReady = st.video && st.video.readyState >= 2;
  const split = e.framing === 'split' && e.splitMediaId && st.media(e.splitMediaId);
  if (vReady) {
    g.filter = f;
    if (e.framing === 'fit') {
      const bw = Math.max(8, Math.round(W / 10)), bh = Math.max(8, Math.round(H / 10));
      scratch.width = bw; scratch.height = bh;
      const sg = scratch.getContext('2d'); drawCover(sg, st.video, 0, 0, bw, bh);
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = 'high'; g.drawImage(scratch, 0, 0, W, H);
      g.filter = 'none'; g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(0, 0, W, H); g.filter = f;
      const s = Math.min(W / st.sw, H / st.sh), vw = st.sw * s, vh = st.sh * s;
      g.drawImage(st.video, (W - vw) / 2, (H - vh) / 2, vw, vh);
    } else if (split) {
      const hTop = evenRound(H / 2);
      drawFill(g, st.video, st.sw, st.sh, 0, 0, W, hTop, e, p);
      const m = st.media(e.splitMediaId);
      g.save(); drawCover(g, m.el, 0, hTop, W, H - hTop); g.restore();
    } else {
      drawFill(g, st.video, st.sw, st.sh, 0, 0, W, H, e, p);
    }
    g.filter = 'none';
  }
  if (e.border && e.border.on) {
    const bt = Math.max(2, (clamp(num(e.border.width, 12), 1, 60) / 1080) * Math.min(W, H));
    g.strokeStyle = e.border.color || '#2f6bff'; g.lineWidth = bt * 2; g.strokeRect(0, 0, W, H);
  }
  for (const ov of e.overlays || []) {
    const m = st.media(ov.mediaId); if (!m || m.kind !== 'image') continue;
    const a = ov.start || 0, b = ov.end == null ? D : ov.end;
    if (tClip < a - 0.001 || tClip > b + 0.001) continue;
    const [ew, eh] = dims(m.el); if (!ew) continue;
    const r = overlayRect(ov, W, H, ew, eh);
    g.drawImage(m.el, r.x, r.y, r.w, r.h);
    if (st.showSel === ov.id) { g.save(); g.setLineDash([8, 6]); g.lineWidth = 2; g.strokeStyle = '#22d3ee'; g.strokeRect(r.x - 3, r.y - 3, r.w + 6, r.h + 6); g.restore(); }
  }
  drawSubs(g, W, H, e.subs, e.captions, st.t);
  const tDur = Math.min(0.4, D / 4);
  const col = (k) => (k === 'flash' ? '255,255,255' : '0,0,0');
  if (e.transIn && e.transIn !== 'none' && tClip < tDur) { g.fillStyle = `rgba(${col(e.transIn)},${1 - tClip / tDur})`; g.fillRect(0, 0, W, H); }
  if (e.transOut && e.transOut !== 'none' && tClip > D - tDur) { g.fillStyle = `rgba(${col(e.transOut)},${(tClip - (D - tDur)) / tDur})`; g.fillRect(0, 0, W, H); }
  g.restore();
}

/* ---------- elementos de medios (imágenes / video de pantalla dividida) ---------- */
function makeMediaEl(item, url) {
  if (item.kind === 'image') { const im = new Image(); im.src = url; return im; }
  const v = document.createElement('video');
  v.src = url; v.muted = true; v.loop = true; v.playsInline = true; v.preload = 'auto';
  return v;
}
const waitEvent = (el, ev, ms = 15000) => new Promise((res, rej) => { const t = setTimeout(() => { el.removeEventListener(ev, h); rej(new Error('Tiempo de espera agotado')); }, ms); const h = () => { clearTimeout(t); res(); }; el.addEventListener(ev, h, { once: true }); });
async function seekTo(video, t) {
  if (Math.abs(video.currentTime - t) < 0.01 && video.readyState >= 2) return;
  const p = waitEvent(video, 'seeked'); video.currentTime = t; await p;
}

/* ---------- exportación en el dispositivo ---------- */
function pickMime() {
  const types = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  return types.find((t) => window.MediaRecorder && MediaRecorder.isTypeSupported(t)) || '';
}

/**
 * Exporta un clip grabando el compositor en tiempo real (MediaRecorder).
 * args: { source:{url,width,height}, clip, media: [{id,kind,url}], quality, onProgress(f), signal }
 * Devuelve { blob, mime, ext, duration }.
 */
async function exportClip({ source, clip, media, onProgress, signal }) {
  if (!window.MediaRecorder) throw new Error('Este dispositivo no permite grabar video desde la app (falta MediaRecorder).');
  const mime = pickMime();
  if (!mime) throw new Error('El WebView de este teléfono no puede crear archivos de video. Actualizá "Android System WebView" desde Play Store.');
  await loadFonts();
  const e = clip.edit, speed = clamp(num(e.speed, 1), 0.5, 2);
  const [W, H] = outSize(e.aspect, e.quality);
  const D = (clip.end - clip.start) / speed;
  const canvas = document.createElement('canvas'); canvas.width = W; canvas.height = H;
  const g = canvas.getContext('2d', { alpha: false });

  const video = document.createElement('video');
  video.src = source.url; video.playsInline = true; video.preload = 'auto'; video.crossOrigin = 'anonymous';
  video.style.cssText = 'position:fixed;left:-9999px;top:0;width:2px;height:2px';
  document.body.append(video);
  const els = new Map();
  const cleanups = [() => { video.pause(); video.removeAttribute('src'); video.load(); video.remove(); }];
  let ac = null;
  try {
    await waitEvent(video, 'loadeddata', 30000);
    const sw = video.videoWidth || source.width, sh = video.videoHeight || source.height;
    // medios usados
    const used = new Set([...(e.overlays || []).map((o) => o.mediaId), e.framing === 'split' ? e.splitMediaId : null].filter(Boolean));
    for (const id of used) {
      const it = media.find((m) => m.id === id); if (!it || it.kind === 'audio') continue;
      const el = makeMediaEl(it, it.url);
      document.body.append(el); el.style.cssText = 'position:fixed;left:-9999px;top:0;width:2px;height:2px';
      cleanups.push(() => { try { el.pause && el.pause(); el.remove(); } catch {} });
      await (it.kind === 'image' ? (el.decode ? el.decode().catch(() => null) : waitEvent(el, 'load')) : waitEvent(el, 'loadeddata', 20000).catch(() => null));
      els.set(id, { el, kind: it.kind });
    }
    // audio
    ac = new (window.AudioContext || window.webkitAudioContext)();
    cleanups.push(() => ac.close().catch(() => {}));
    await ac.resume().catch(() => {});
    const dest = ac.createMediaStreamDestination();
    const master = ac.createGain(); master.connect(dest);
    const vsrc = ac.createMediaElementSource(video); vsrc.connect(master);
    const decode = async (id) => { const it = media.find((m) => m.id === id); if (!it) return null; const buf = await (await fetch(it.url)).arrayBuffer(); return ac.decodeAudioData(buf); };
    const musicBuf = e.music && e.music.mediaId ? await decode(e.music.mediaId).catch(() => null) : null;
    const sfxBufs = [];
    for (const f of (e.sfx || []).slice(0, 20)) { const b = await decode(f.mediaId).catch(() => null); if (b) sfxBufs.push({ b, at: clamp(num(f.at, 0), 0, D), vol: clamp(num(f.volume, 0.8), 0, 2) }); }

    await seekTo(video, clip.start);
    video.playbackRate = speed;
    const stRender = (t) => drawFrame(g, W, H, { video, sw, sh, e, start: clip.start, end: clip.end, t, media: (id) => els.get(id) || null });
    stRender(clip.start);

    const stream = canvas.captureStream(30);
    dest.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr));
    const bitrate = Math.round(clamp(W * H * 4.2, 2.5e6, 16e6));
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bitrate, audioBitsPerSecond: 160000 });
    const chunks = [];
    rec.ondataavailable = (ev) => { if (ev.data && ev.data.size) chunks.push(ev.data); };
    const stopped = new Promise((res, rej) => { rec.onstop = res; rec.onerror = (ev) => rej(ev.error || new Error('Falló la grabación')); });

    // arranque sincronizado
    const playing = waitEvent(video, 'playing', 15000);
    video.play().catch(() => {});
    for (const { el } of els.values()) if (el.play) el.play().catch(() => {});
    await playing;
    const base = ac.currentTime + 0.05;
    const tDur = Math.min(0.4, D / 4);
    if (e.transIn && e.transIn !== 'none') { master.gain.setValueAtTime(0, base); master.gain.linearRampToValueAtTime(1, base + tDur); }
    if (e.transOut && e.transOut !== 'none') { master.gain.setValueAtTime(1, base + D - tDur); master.gain.linearRampToValueAtTime(0, base + D); }
    if (musicBuf) { const n = ac.createBufferSource(); n.buffer = musicBuf; n.loop = true; const gn = ac.createGain(); gn.gain.value = clamp(num(e.music.volume, 0.25), 0, 1.5); n.connect(gn).connect(master); n.start(base); }
    for (const s of sfxBufs) { const n = ac.createBufferSource(); n.buffer = s.b; const gn = ac.createGain(); gn.gain.value = s.vol; n.connect(gn).connect(master); n.start(base + s.at); }
    rec.start(1000);

    let last = 0, lastT = video.currentTime, lastMove = performance.now();
    await new Promise((resolve, reject) => {
      const tick = (now) => {
        if (signal?.aborted) return resolve();
        const t = video.currentTime;
        if (t > lastT + 0.001) { lastT = t; lastMove = now; }
        if (now - lastMove > 12000) return reject(new Error('El video se trabó mientras se exportaba. Probá con una calidad menor.'));
        if (t >= clip.end - 0.02 || video.ended) return resolve();
        if (now - last >= 30) { last = now; stRender(t); onProgress && onProgress(clamp((t - clip.start) / (clip.end - clip.start), 0, 0.99)); }
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
    stRender(Math.min(clip.end, video.currentTime));
    await new Promise((r) => setTimeout(r, 250));
    video.pause();
    if (rec.state !== 'inactive') rec.stop();
    await stopped;
    if (signal?.aborted) { const err = new Error('Cancelado'); err.code = 'ABORT'; throw err; }
    const blob = new Blob(chunks, { type: mime.split(';')[0] });
    if (!blob.size) throw new Error('La grabación quedó vacía.');
    onProgress && onProgress(1);
    return { blob, mime: mime.split(';')[0], ext: mime.startsWith('video/mp4') ? 'mp4' : 'webm', duration: D };
  } finally {
    for (const c of cleanups.reverse()) { try { c(); } catch {} }
  }
}

CZ.render = { CSS_FILTER, FONTS, outSize, loadFonts, currentCaption, drawFrame, drawSubs, overlayRect, makeMediaEl, seekTo, waitEvent, exportClip, pickMime, dims };
})();
