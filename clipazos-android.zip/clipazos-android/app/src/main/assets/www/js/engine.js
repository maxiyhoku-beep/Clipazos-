'use strict';
/* Motor de IA en el dispositivo: transcripción (API tipo Whisper) y selección de clips (Claude o heurística). */
(() => {
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const abortErr = () => Object.assign(new Error('Cancelado'), { code: 'ABORT' });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------- Configuración ---------- */
const DEFAULT_SETTINGS = { language: 'auto', transcribe: { key: '', baseUrl: 'https://api.openai.com/v1', model: 'whisper-1' }, llm: { key: '', baseUrl: 'https://api.anthropic.com', model: 'claude-sonnet-5-5' } };
async function getSettings() {
  const s = (await CZ.db.get('kv', 'settings')) || {};
  return { ...DEFAULT_SETTINGS, ...s, transcribe: { ...DEFAULT_SETTINGS.transcribe, ...(s.transcribe || {}) }, llm: { ...DEFAULT_SETTINGS.llm, ...(s.llm || {}) } };
}
async function saveSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch, transcribe: { ...cur.transcribe, ...(patch.transcribe || {}) }, llm: { ...cur.llm, ...(patch.llm || {}) } };
  await CZ.db.put('kv', 'settings', next);
  return next;
}

/* ---------- HTTP (lo hace Android; sin CORS) ---------- */
async function http(spec, signal) {
  if (signal?.aborted) throw abortErr();
  const r = await CZ.native.http(spec);
  if (signal?.aborted) throw abortErr();
  if (!r || r.error) throw new Error(r?.error || 'Falló la conexión');
  return r;
}

/* ---------- Transcripción ---------- */
function normalizeTranscript(parts) {
  const segments = [], words = [];
  let language = null;
  for (const { offset, data } of parts) {
    language = language || data.language || null;
    const segs = (data.segments || []).filter((s) => !(s.no_speech_prob > 0.85 && s.avg_logprob < -1));
    for (const s of segs) { const text = String(s.text || '').trim(); if (text) segments.push({ start: s.start + offset, end: s.end + offset, text }); }
    if (Array.isArray(data.words) && data.words.length) {
      for (const w of data.words) { const t = String(w.word ?? w.text ?? '').trim(); if (t) words.push({ w: t, s: w.start + offset, e: w.end + offset }); }
    } else {
      for (const s of segs) {
        const toks = String(s.text || '').trim().split(/\s+/).filter(Boolean);
        const step = (s.end - s.start) / Math.max(1, toks.length);
        toks.forEach((t, i) => words.push({ w: t, s: s.start + offset + i * step, e: s.start + offset + (i + 1) * step, est: true }));
      }
    }
  }
  segments.sort((a, b) => a.start - b.start);
  words.sort((a, b) => a.s - b.s);
  const valid = words.filter((w) => segments.some((s) => w.s >= s.start - 0.3 && w.s <= s.end + 0.3));
  return { language, segments, words: valid, wordTiming: words.some((w) => w.est) ? 'estimated' : 'precise' };
}

async function transcribeChunks(pid, chunks, settings, language, { signal, onProgress }) {
  const c = settings.transcribe;
  const parts = [];
  for (let i = 0; i < chunks.length; i++) {
    const ch = chunks[i];
    let lastErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (signal?.aborted) throw abortErr();
      try {
        const fields = { model: c.model, response_format: 'verbose_json', 'timestamp_granularities[]': ['word', 'segment'] };
        if (language && language !== 'auto') fields.language = language;
        const r = await http({ url: `${c.baseUrl.replace(/\/$/, '')}/audio/transcriptions`, method: 'POST', headers: { Authorization: `Bearer ${c.key}` }, multipart: { fields, file: { field: 'file', rel: ch.rel, name: 'audio.wav', type: 'audio/wav' } } }, signal);
        if (r.status < 200 || r.status >= 300) { const err = new Error(`El servicio de transcripción respondió ${r.status}: ${String(r.text).slice(0, 300)}`); err.status = r.status; throw err; }
        parts.push({ offset: ch.offset, data: JSON.parse(r.text) });
        lastErr = null; break;
      } catch (e) {
        if (e.code === 'ABORT') throw e;
        lastErr = e;
        if (e.status && e.status < 500 && e.status !== 429) break;
        await sleep(1500 * (attempt + 1));
      }
    }
    if (lastErr) throw lastErr;
    onProgress && onProgress((i + 1) / chunks.length);
  }
  return normalizeTranscript(parts);
}

/* ---------- Selección de clips ---------- */
const fmtT = (s) => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
function percentile(arr, p) { if (!arr.length) return 0; const a = [...arr].sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.floor((p / 100) * a.length))]; }
function energyNormalizer(energy) {
  const voiced = energy.filter((v) => v > -80);
  const base = voiced.length ? voiced : energy;
  const lo = percentile(base, 10), hi = percentile(base, 95);
  const span = Math.max(3, hi - lo);
  return (db) => clamp((db - lo) / span, 0, 1);
}
function windowEnergy(energy, norm, a, b) {
  const s = Math.max(0, Math.floor(a)), e = Math.min(energy.length, Math.ceil(b));
  if (e <= s) return 0;
  const vals = []; for (let i = s; i < e; i++) vals.push(norm(energy[i]));
  const mean = vals.reduce((x, y) => x + y, 0) / vals.length;
  const top = [...vals].sort((x, y) => y - x).slice(0, Math.max(1, Math.round(vals.length * 0.3)));
  return 0.4 * mean + 0.6 * (top.reduce((x, y) => x + y, 0) / top.length);
}
const HYPE = /(jaj|jej|haha|lol|no puede ser|increíble|increible|qué locura|que locura|wow|dios|loco|boludo|mirá|mira |sorpresa|nunca|siempre|secreto|error|problema|verdad|mentira|amor|odio|miedo|ganamos|perdimos|gol|campe|final|impresionante|ojo|cuidado|atención|atencion|importante|clave|truco)/i;
function titleFrom(text) {
  let t = String(text).replace(/\s+/g, ' ').trim().replace(/^[¿¡"'\-–—\s]+/, '');
  if (t.length > 58) t = t.slice(0, 58).replace(/\s+\S*$/, '') + '…';
  return t.charAt(0).toUpperCase() + t.slice(1) || 'Momento destacado';
}
function heuristicCandidates(segments, energy, minDur, maxDur) {
  const norm = energyNormalizer(energy);
  const rates = segments.map((s) => s.text.split(/\s+/).length / Math.max(0.5, s.end - s.start));
  const medRate = percentile(rates, 50) || 2;
  const out = [];
  for (let i = 0; i < segments.length; i++) {
    let best = -1;
    for (let j = i; j < segments.length; j++) { const d = segments[j].end - segments[i].start; if (d > maxDur) break; if (d >= minDur) best = j; }
    if (best < 0) continue;
    const start = segments[i].start, end = segments[best].end;
    const text = segments.slice(i, best + 1).map((s) => s.text).join(' ');
    const nWords = text.split(/\s+/).length;
    const e = windowEnergy(energy, norm, start, end);
    const rate = clamp(nWords / (end - start) / (medRate * 1.5), 0, 1);
    const marks = (text.match(/[!¡?¿]/g) || []).length;
    const hype = (text.match(new RegExp(HYPE.source, 'gi')) || []).length;
    const excite = clamp((marks * 0.6 + hype * 1.2) / Math.max(4, nWords / 12), 0, 1);
    const gapBefore = i === 0 ? 1 : segments[i].start - segments[i - 1].end;
    const selfContained = (gapBefore >= 0.4 || /[.!?]$/.test(segments[i - 1]?.text || '') ? 0.5 : 0.1) + (/[.!?…]$/.test(segments[best].text) ? 0.5 : 0.1);
    const raw = 0.4 * e + 0.2 * rate + 0.25 * excite + 0.15 * selfContained;
    const drivers = [['energía de voz alta', e], ['ritmo de habla rápido', rate], ['expresiones de reacción o énfasis', excite], ['inicio y cierre completos', selfContained]].sort((a, b) => b[1] - a[1]).slice(0, 2).map((d) => d[0]);
    out.push({ start, end, raw, score: Math.round(38 + 58 * clamp(raw, 0, 1)), title: titleFrom(segments[i].text), description: `Fragmento con ${drivers.join(' y ')}.`, category: hype > 1 ? 'reacción' : marks > 2 ? 'emocionante' : 'destacado', reason: `Selección por análisis de audio y texto (${drivers.join(', ')}).`, engine: 'heuristic' });
  }
  return out;
}
function audioOnlyCandidates(energy, duration, minDur, maxDur) {
  const norm = energyNormalizer(energy);
  const T = Math.round((minDur + maxDur) / 2);
  const out = [];
  for (let s = 0; s + minDur <= duration; s += 5) {
    const e = Math.min(duration, s + T);
    const w = windowEnergy(energy, norm, s, e);
    const sl = energy.slice(Math.floor(s), Math.ceil(e)).map(norm);
    const mean = sl.reduce((a, b) => a + b, 0) / Math.max(1, sl.length);
    const varc = sl.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, sl.length);
    const raw = 0.75 * w + 0.25 * clamp(Math.sqrt(varc) * 3, 0, 1);
    out.push({ start: s, end: e, raw, score: Math.round(35 + 50 * clamp(raw, 0, 1)), title: `Momento intenso en ${fmtT(s)}`, description: 'Pico de energía de audio. Sin transcripción no se puede resumir el contenido.', category: 'destacado', reason: 'Selección solo por análisis de audio (no hay servicio de transcripción configurado).', engine: 'audio' });
  }
  return out;
}
function overlapFrac(a, b) { const o = Math.min(a.end, b.end) - Math.max(a.start, b.start); return o <= 0 ? 0 : o / Math.min(a.end - a.start, b.end - b.start); }
function pickDiverse(cands, count, gap = 4) {
  const sorted = [...cands].sort((a, b) => (b.score - a.score) || (b.raw ?? 0) - (a.raw ?? 0));
  const chosen = [];
  for (const c of sorted) {
    if (chosen.length >= count) break;
    if (chosen.some((x) => overlapFrac(x, c) > 0.05 || (c.start < x.end + gap && c.end > x.start - gap))) continue;
    chosen.push(c);
  }
  return chosen;
}
function snapClip(raw, segments, minDur, maxDur, duration) {
  let start = Number(raw.start), end = Number(raw.end);
  if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return null;
  start = clamp(start, 0, duration); end = clamp(end, 0, duration);
  if (segments.length) {
    let si = 0;
    for (let i = 0; i < segments.length; i++) { if (segments[i].start <= start + 0.6) si = i; else break; }
    let ei = si;
    for (let i = si; i < segments.length; i++) { ei = i; if (segments[i].end >= end - 0.6) break; }
    while (ei > si && segments[ei].end - segments[si].start > maxDur) ei--;
    while (segments[ei].end - segments[si].start < minDur && ei + 1 < segments.length && segments[ei + 1].end - segments[si].start <= maxDur) ei++;
    start = Math.max(0, segments[si].start - 0.15); end = Math.min(duration, segments[ei].end + 0.25);
  } else if (end - start > maxDur) end = start + maxDur;
  const d = end - start;
  if (d < minDur - 0.5 || d > maxDur + 0.5) return null;
  return { start, end };
}
function extractJson(text) { const m = /\{[\s\S]*\}/.exec(text); if (!m) throw new Error('Respuesta de la IA sin JSON'); return JSON.parse(m[0]); }

async function llmCandidates({ segments, energy, duration, count, minDur, maxDur, settings, signal, onProgress }) {
  const c = settings.llm;
  const norm = energyNormalizer(energy);
  const WINDOW = 2400;
  const windows = []; for (let a = 0; a < duration; a += WINDOW) windows.push([a, Math.min(duration, a + WINDOW)]);
  const system = 'Sos un editor experto en contenido viral para TikTok, YouTube Shorts e Instagram Reels. Recibís la transcripción con marcas de tiempo de un video largo y elegís los mejores momentos para convertir en clips. Respondé SOLO con un objeto JSON válido, sin texto adicional ni bloques de código.';
  const all = [];
  for (let wi = 0; wi < windows.length; wi++) {
    const [a, b] = windows[wi];
    const segs = segments.filter((s) => s.start >= a - 1 && s.start < b);
    if (!segs.length) continue;
    const ask = clamp(Math.ceil(count * ((b - a) / duration) * 1.6) + 2, 3, 25);
    const lines = segs.map((s) => { const hot = norm(percentile(energy.slice(Math.floor(s.start), Math.ceil(s.end)), 90)) > 0.85 ? ' 🔊' : ''; return `[${s.start.toFixed(1)}-${s.end.toFixed(1)}]${hot} ${s.text}`; }).join('\n');
    const user = [
      `Duración total del video: ${fmtT(duration)}. Fragmento analizado: ${fmtT(a)} a ${fmtT(b)}.`,
      `Elegí hasta ${ask} momentos candidatos. Cada clip debe durar entre ${minDur} y ${maxDur} segundos.`,
      'Criterios: momentos divertidos, reacciones, frases interesantes, momentos emocionantes, discusiones, giros inesperados, información valiosa e historias con sentido propio.',
      'Reglas: el clip debe entenderse por sí solo (gancho al inicio, cierre natural al final); empezá y terminá en los límites de las frases dadas; evitá candidatos repetitivos o que se solapen; el marcador 🔊 indica audio con mucha energía (pista, no obligación).',
      'La "score" (1-99) es una estimación del potencial de interacción, no una garantía de viralidad.',
      'Formato exacto: {"clips":[{"start":<seg>,"end":<seg>,"score":<1-99>,"title":"<título atractivo en español, máx 70 caracteres>","description":"<1-2 oraciones en español>","category":"divertido|reacción|frase|emocionante|discusión|inesperado|informativo|historia","reason":"<por qué funciona, breve>"}]}',
      '', 'TRANSCRIPCIÓN (tiempos en segundos):', lines,
    ].join('\n');
    const r = await http({ url: `${c.baseUrl.replace(/\/$/, '')}/v1/messages`, method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': c.key, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: c.model, max_tokens: 6000, system, messages: [{ role: 'user', content: user }] }) }, signal);
    if (r.status < 200 || r.status >= 300) throw new Error(`La API de Claude respondió ${r.status}: ${String(r.text).slice(0, 300)}`);
    const data = JSON.parse(r.text);
    const text = (data.content || []).filter((x) => x.type === 'text').map((x) => x.text).join('');
    for (const raw of extractJson(text).clips || []) all.push(raw);
    onProgress && onProgress((wi + 1) / windows.length);
  }
  const out = [];
  for (const raw of all) {
    const snapped = snapClip(raw, segments, minDur, maxDur, duration);
    if (!snapped) continue;
    out.push({ ...snapped, score: clamp(Math.round(Number(raw.score) || 60), 1, 99), title: String(raw.title || '').slice(0, 90) || titleFrom(segments.find((s) => s.start >= snapped.start)?.text || ''), description: String(raw.description || '').slice(0, 300), category: String(raw.category || 'destacado').slice(0, 20), reason: String(raw.reason || '').slice(0, 300), engine: 'claude' });
  }
  return out;
}

async function selectClips({ transcript, energy, duration, count, minDur, maxDur, settings, signal, onProgress }) {
  const warnings = [];
  let chosen = [], engine = 'audio';
  const segments = transcript ? transcript.segments : [];
  if (transcript && segments.length) {
    let llm = [];
    if (settings.llm.key) {
      try { llm = await llmCandidates({ segments, energy, duration, count, minDur, maxDur, settings, signal, onProgress }); engine = 'claude'; }
      catch (e) { if (e.code === 'ABORT') throw e; warnings.push(`No se pudo usar Claude (${e.message}). Se usó la selección automática por audio y texto.`); }
    } else warnings.push('No hay clave de Claude configurada: los clips se eligieron con una heurística de audio y texto, sin comprensión del contenido.');
    chosen = pickDiverse(llm, count);
    if (chosen.length < count) {
      const heur = heuristicCandidates(segments, energy, minDur, maxDur).filter((h) => !chosen.some((x) => overlapFrac(x, h) > 0.05));
      const fill = pickDiverse([...chosen, ...heur], count).filter((x) => !chosen.includes(x));
      chosen = chosen.concat(fill);
      if (engine !== 'claude') engine = 'heuristic';
    }
  } else {
    warnings.push(transcript ? 'La transcripción no detectó voz. Los clips se eligieron solo por energía de audio.' : 'No hay servicio de transcripción configurado: los clips se eligieron solo por energía de audio y no habrá subtítulos automáticos.');
    chosen = pickDiverse(audioOnlyCandidates(energy, duration, minDur, maxDur), count);
  }
  if (chosen.length < count) warnings.push(chosen.length === 1 ? 'Solo se encontró 1 momento que cumple la duración pedida.' : `Solo se encontraron ${chosen.length} momentos que cumplen la duración pedida.`);
  chosen.sort((a, b) => b.score - a.score);
  return { clips: chosen, warnings, engine };
}

CZ.engine = { getSettings, saveSettings, transcribeChunks, selectClips, normalizeTranscript, snapClip, pickDiverse, heuristicCandidates, audioOnlyCandidates, fmtT, abortErr };
})();
