'use strict';
/* Puente con la parte nativa de Android (window.Android) + almacenamiento local (IndexedDB). */
window.CZ = window.CZ || {};

/* ------------------------------------------------------------------ */
/* Puente nativo                                                        */
/* ------------------------------------------------------------------ */
(() => {
  const pending = new Map();
  let seq = 0;
  window.__native = {
    resolve(id, res) { const p = pending.get(id); if (p) { pending.delete(id); p.resolve(res); } },
    progress(id, a, b) { const p = pending.get(id); if (p && p.onProgress) p.onProgress(a, b); },
  };
  const A = () => window.Android;
  const callAsync = (method, args, onProgress) => new Promise((resolve, reject) => {
    if (!A() || !A()[method]) return reject(new Error('Esta función solo está disponible dentro de la app de Android.'));
    const id = 'r' + (++seq);
    pending.set(id, { resolve, onProgress });
    try { A()[method](id, ...args); } catch (e) { pending.delete(id); reject(e); }
  });

  const B64_CHUNK = 1536 * 1024; // bytes por trozo hacia el lado nativo
  function toBase64(u8) {
    let s = '';
    const step = 0x8000;
    for (let i = 0; i < u8.length; i += step) s += String.fromCharCode.apply(null, u8.subarray(i, i + step));
    return btoa(s);
  }

  CZ.native = {
    get available() { return !!window.Android; },
    pickVideo: (onProgress) => callAsync('pickVideo', [], onProgress),
    cancelPick: () => { try { A().cancelPick(); } catch {} },
    analyzeAudio: (pid, onProgress) => callAsync('analyzeAudio', [pid], onProgress),
    cancelAnalysis: (pid) => { try { A().cancelAnalysis(pid); } catch {} },
    // Pedido HTTP hecho por Android (evita problemas de CORS). spec: {url, method, headers, body, multipart:{fields, file:{field, rel, name, type}}}
    http: (spec) => callAsync('http', [JSON.stringify(spec)]),
    // Guarda un Blob en Películas/Clipazos (galería). Devuelve {uri, name, size}.
    async saveVideo(blob, name, mime, onProgress) {
      const a = A(); if (!a) throw new Error('No se puede guardar fuera de la app de Android.');
      const h = await a.saveBegin(name, mime);
      if (!h || String(h).startsWith('ERR')) throw new Error(String(h || 'No se pudo crear el archivo').replace(/^ERR:?\s*/, ''));
      try {
        for (let off = 0; off < blob.size; off += B64_CHUNK) {
          const buf = new Uint8Array(await blob.slice(off, off + B64_CHUNK).arrayBuffer());
          const r = await a.saveChunk(h, toBase64(buf));
          if (String(r).startsWith('ERR')) throw new Error(String(r).replace(/^ERR:?\s*/, ''));
          onProgress && onProgress(Math.min(1, (off + buf.length) / blob.size));
        }
        const out = await a.saveEnd(h);
        const j = JSON.parse(out);
        if (j.error) throw new Error(j.error);
        return j;
      } catch (e) { try { a.saveAbort(h); } catch {} throw e; }
    },
    openUri: (uri, mime) => { try { A().openUri(uri, mime); } catch {} },
    share: (uri, mime) => { try { A().share(uri, mime); } catch {} },
    async deleteUri(uri) { try { return !!(await A().deleteUri(uri)); } catch { return false; } },
    deleteProject: (pid) => { try { A().deleteProject(pid); } catch {} },
    keepAwake: (on) => { try { A().keepAwake(!!on); } catch {} },
  };
})();

/* ------------------------------------------------------------------ */
/* IndexedDB: proyectos, blobs (miniaturas, medios), transcripciones    */
/* ------------------------------------------------------------------ */
(() => {
  let dbp = null;
  const open = () => dbp || (dbp = new Promise((resolve, reject) => {
    const r = indexedDB.open('clipazos', 1);
    r.onupgradeneeded = () => { const d = r.result; for (const s of ['projects', 'blobs', 'transcripts', 'kv']) if (!d.objectStoreNames.contains(s)) d.createObjectStore(s); };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error || new Error('No se pudo abrir el almacenamiento local'));
  }));
  const tx = async (store, mode, fn) => {
    const db = await open();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, mode); const s = t.objectStore(store);
      let out; try { out = fn(s); } catch (e) { return reject(e); }
      t.oncomplete = () => resolve(out && 'result' in out ? out.result : undefined);
      t.onerror = () => reject(t.error); t.onabort = () => reject(t.error || new Error('Transacción cancelada'));
    });
  };
  CZ.db = {
    get: (store, key) => tx(store, 'readonly', (s) => s.get(key)),
    put: (store, key, val) => tx(store, 'readwrite', (s) => { s.put(val, key); }),
    del: (store, key) => tx(store, 'readwrite', (s) => { s.delete(key); }),
    all: (store) => tx(store, 'readonly', (s) => s.getAll()),
    keys: (store) => tx(store, 'readonly', (s) => s.getAllKeys()),
    async delPrefix(store, prefix) { const ks = await this.keys(store); for (const k of ks) if (String(k).startsWith(prefix)) await this.del(store, k); },
  };
})();
